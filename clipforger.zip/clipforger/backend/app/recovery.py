"""Job leases, heartbeats and stale-job recovery.

A running job renews its lease while it works. If the process dies (crash, deploy, OOM), the lease
expires, and the next maintenance pass marks the job failed so the user can retry. This replaces the
old 'fail everything on startup' rule, which would have killed live jobs on other instances."""
import logging
import threading
import time
from contextlib import contextmanager

from . import cleanup, db
from .config import settings

log = logging.getLogger("clipforger.recovery")

STALE_PROJECT = "Processing stopped unexpectedly (the server may have restarted). Try again."
STALE_CLIP = "Rendering stopped unexpectedly (the server may have restarted). Try again."


@contextmanager
def heartbeat(table: str, ids: list[str]):
    """Keep the leases on these rows alive while the block runs."""
    ids = list(ids)

    def beat() -> None:
        try:
            db.touch(table, ids, db.utc_iso(settings.job_lease_seconds))
        except Exception:
            log.warning("Heartbeat failed for %s; the lease may expire", table, exc_info=True)

    beat()
    stop = threading.Event()

    def loop() -> None:
        while not stop.wait(settings.heartbeat_seconds):
            beat()

    thread = threading.Thread(target=loop, name=f"heartbeat-{table}", daemon=True)
    thread.start()
    try:
        yield
    finally:
        stop.set()
        thread.join(timeout=5)


def reap() -> dict:
    """Mark jobs with expired leases as failed. Returns counts."""
    return {"projects": db.fail_stale_projects(STALE_PROJECT), "clips": db.fail_stale_clips(STALE_CLIP)}


_started = False


def start_background() -> None:
    """Start the maintenance thread: reap stale jobs and process the storage cleanup queue."""
    global _started
    if _started:
        return
    _started = True

    def loop() -> None:
        while True:
            try:
                reaped = reap()
                if any(reaped.values()):
                    log.warning("Recovered stale jobs: %s", reaped)
                cleanup.sweep()
            except Exception:
                log.exception("Maintenance pass failed; will retry")
            time.sleep(settings.maintenance_seconds)

    threading.Thread(target=loop, name="maintenance", daemon=True).start()
