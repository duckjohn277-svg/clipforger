"""Cancellation and upload safety for background jobs.

Jobs run in this process's thread pool, but a delete request may arrive on any instance. So the
database is the source of truth: a job checks that its project still exists at each step, and an
in-process cancel just drops jobs that have not started yet."""
import logging
import threading
from concurrent.futures import Future

from . import db

log = logging.getLogger("clipforger.jobs")

_lock = threading.Lock()
_futures: dict[str, set[Future]] = {}


class Cancelled(Exception):
    """The project (or clip) was deleted while a job was working on it. Not an error: stop quietly."""


def track(project_id: str, future) -> None:
    """Remember a submitted job so it can be cancelled if it has not started. Accepts None (test stubs)."""
    if not isinstance(future, Future):
        return
    with _lock:
        _futures.setdefault(project_id, set()).add(future)
    future.add_done_callback(lambda f: _forget(project_id, f))


def _forget(project_id: str, future: Future) -> None:
    with _lock:
        s = _futures.get(project_id)
        if s is not None:
            s.discard(future)
            if not s:
                del _futures[project_id]


def cancel(project_id: str) -> int:
    """Cancel queued jobs for a project. Running jobs stop at their next checkpoint. Returns jobs cancelled."""
    with _lock:
        futures = list(_futures.get(project_id, ()))
    return sum(1 for f in futures if f.cancel())


def checkpoint(project_id: str) -> None:
    """Raise Cancelled if the project has been deleted. Call between expensive steps."""
    if not db.project_exists(project_id):
        raise Cancelled(project_id)


def guard_upload(project_id: str, bucket: str, path: str, clip_id: str | None = None) -> None:
    """Call right after uploading an object. If the project or clip was deleted while the upload was in
    flight, remove the object now so it is not orphaned.

    Why this is safe: deletion removes database rows before it removes files. If the rows still exist
    when we check here, the deletion's later file cleanup will see the object. If they are already gone,
    this check removes it."""
    gone = not db.project_exists(project_id) or (clip_id is not None and not db.clip_exists(clip_id))
    if not gone:
        return
    owner = path.split("/", 1)[0]
    try:
        db.delete_objects(bucket, [path])
    except Exception:
        log.exception("Could not delete orphaned %s/%s right away; queued for cleanup", bucket, path)
        db.enqueue_cleanup(bucket, path, project_id, owner)
    raise Cancelled(project_id)
