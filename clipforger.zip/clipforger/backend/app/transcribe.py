import threading

from .config import settings
from .errors import PipelineError

_model = None
_lock = threading.Lock()


def _get_model():
    global _model
    with _lock:
        if _model is None:
            try:
                from faster_whisper import WhisperModel
            except ImportError:
                raise PipelineError("The transcription engine is not installed on the server (pip install faster-whisper).")
            _model = WhisperModel(settings.whisper_model, device=settings.whisper_device,
                                  compute_type=settings.whisper_compute)
        return _model


def transcribe(audio_path: str) -> dict:
    """Whisper transcription with word-level timestamps. Voice-activity filtering skips silence."""
    segs, info = _get_model().transcribe(audio_path, word_timestamps=True, vad_filter=True)
    segments, words = [], []
    for s in segs:
        segments.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()})
        for w in s.words or []:
            words.append({"start": round(w.start, 2), "end": round(w.end, 2), "word": w.word.strip(),
                          "prob": round(w.probability, 2)})
    if not words:
        raise PipelineError("No speech was detected in this video, so there is nothing to clip.")
    return {"language": info.language, "segments": segments, "words": words}
