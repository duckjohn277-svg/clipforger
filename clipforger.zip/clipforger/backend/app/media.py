import json
import subprocess


from .errors import PipelineError as MediaError  # noqa: F401


def _run(cmd: list[str], timeout: int) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        raise MediaError("FFmpeg is not installed on the server.")
    except subprocess.TimeoutExpired:
        raise MediaError("Processing took too long and was stopped.")
    if p.returncode != 0:
        raise MediaError("FFmpeg could not read this file. It may be corrupted or use an unsupported codec.")
    return p.stdout


def probe(path: str) -> dict:
    out = _run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path], 60)
    info = json.loads(out)
    streams = info.get("streams", [])
    if not any(s.get("codec_type") == "video" for s in streams):
        raise MediaError("This file has no video track.")
    if not any(s.get("codec_type") == "audio" for s in streams):
        raise MediaError("This video has no audio track, so there is nothing to transcribe.")
    try:
        duration = float(info["format"]["duration"])
    except (KeyError, ValueError):
        raise MediaError("Could not determine the video's duration.")
    return {"duration": duration}


def extract_audio(src: str, dst: str, duration: float) -> None:
    """16 kHz mono MP3: small, and the sample rate speech models expect."""
    _run(["ffmpeg", "-nostdin", "-y", "-i", src, "-vn", "-ac", "1", "-ar", "16000",
          "-c:a", "libmp3lame", "-b:a", "48k", dst], timeout=max(120, int(duration)))
