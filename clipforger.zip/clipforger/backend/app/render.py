import logging
import os
import shutil
import subprocess
import tempfile

from . import captions, db, jobs, recovery
from .errors import PipelineError

log = logging.getLogger("clipforger.render")
SIZES = {"9:16": (1080, 1920), "1:1": (1080, 1080), "16:9": (1920, 1080)}
FONTS = os.path.join(os.path.dirname(os.path.dirname(__file__)), "fonts")


def build_graph(w: int, h: int, fit: str, with_captions: bool) -> str:
    if fit == "blur":
        g = (f"[0:v]split[a][b];[a]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=30:5[bg];"
             f"[b]scale={w}:{h}:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1")
    else:
        g = f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1"
    return g + (",ass=subs.ass:fontsdir=fonts[v]" if with_captions else "[v]")


def render_clip(src: str, dst: str, start: float, end: float, words: list[dict], opts: dict, work: str) -> None:
    """Cut [start, end] from src, reframe to the chosen aspect ratio, burn in captions, write MP4 to dst."""
    w, h = SIZES[opts["aspect"]]
    cap = opts["captions"]
    use_captions = bool(cap["enabled"] and words)
    if use_captions:
        with open(os.path.join(work, "subs.ass"), "w", encoding="utf-8") as f:
            f.write(captions.generate_ass(words, start, end, w, h, cap))
        if not os.path.isdir(os.path.join(work, "fonts")):
            shutil.copytree(FONTS, os.path.join(work, "fonts"))
    dur = end - start
    cmd = ["ffmpeg", "-nostdin", "-y", "-ss", f"{start:.3f}", "-i", src, "-t", f"{dur:.3f}",
           "-filter_complex", build_graph(w, h, opts["fit"], use_captions), "-map", "[v]", "-map", "0:a?",
           "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", dst]
    try:
        p = subprocess.run(cmd, cwd=work, capture_output=True, text=True, timeout=max(300, int(dur * 15)))
    except subprocess.TimeoutExpired:
        raise PipelineError("Rendering took too long and was stopped.")
    if p.returncode != 0:
        log.error("ffmpeg failed: %s", p.stderr[-800:])
        raise PipelineError("FFmpeg could not render this clip.")


def render_job(project_id: str, clip_ids: list[str], opts: dict) -> None:
    work = tempfile.mkdtemp(prefix="clipforger-render-")
    try:
        with recovery.heartbeat("clips", clip_ids):
            _render_all(project_id, clip_ids, opts, work)
    except jobs.Cancelled:
        log.info("Rendering stopped: project %s was deleted", project_id)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _render_all(project_id: str, clip_ids: list[str], opts: dict, work: str) -> None:
    try:
        jobs.checkpoint(project_id)
        p = db.get_project(project_id)
        if not p:
            raise jobs.Cancelled(project_id)
        clips = {c["id"]: c for c in db.get_clips(project_id)}
        words = db.get_transcript_words(project_id)
        src = os.path.join(work, "src" + os.path.splitext(p["storage_path"])[1])
        db.download_video(p["storage_path"], src)  # downloaded once for all clips in this job
        for cid in clip_ids:
            jobs.checkpoint(project_id)
            c = clips.get(cid)
            if not c:
                continue  # the clip was replaced by a re-analysis; nothing to render
            db.update_clip(cid, render_status="rendering")
            try:
                out = os.path.join(work, f"{cid}.mp4")
                render_clip(src, out, float(c["start_seconds"]), float(c["end_seconds"]), words, opts, work)
                path = f"{p['user_id']}/{project_id}/{cid}.mp4"
                db.upload_clip(path, out)
                jobs.guard_upload(project_id, "clips", path, clip_id=cid)
                db.update_clip(cid, render_status="done", render_error=None, output_path=path, render_options=opts)
            except jobs.Cancelled:
                raise
            except PipelineError as e:
                db.update_clip(cid, render_status="failed", render_error=str(e))
            except Exception:
                log.exception("Render failed for clip %s", cid)
                db.update_clip(cid, render_status="failed", render_error="Something went wrong while rendering. Try again.")
    except jobs.Cancelled:
        raise
    except Exception:
        log.exception("Render job failed for project %s", project_id)
        for cid in clip_ids:
            db.update_clip(cid, render_status="failed", render_error="Could not start rendering. Try again.")
