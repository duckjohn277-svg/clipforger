"""Per-user rate limits for expensive endpoints.

Limits are keyed by the authenticated user, so they cannot be bypassed by changing IP. Counts live in
Redis when REDIS_URL is set (shared by every instance), otherwise in process memory. If Redis is
unreachable, requests fall back to in-process counting instead of failing open."""
import logging
import math
import re
import threading
import time

from fastapi import Depends, HTTPException

from .auth import current_user_id
from .config import settings

log = logging.getLogger("clipforger.ratelimit")
_UNITS = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}
_SPEC = re.compile(r"^\s*(\d+)\s*/\s*(second|minute|hour|day)s?\s*$")


def parse(spec: str) -> tuple[int, int]:
    """'10/hour' -> (10, 3600)."""
    m = _SPEC.match(spec or "")
    if not m:
        raise ValueError(f"Bad rate limit {spec!r}. Use the form 10/hour.")
    return int(m.group(1)), _UNITS[m.group(2)]


class MemoryStore:
    name = "memory"

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._windows: dict[str, tuple[int, float]] = {}

    def hit(self, key: str, window: int) -> tuple[int, int]:
        now = time.time()
        with self._lock:
            if len(self._windows) > 10_000:
                self._windows = {k: v for k, v in self._windows.items() if v[1] > now}
            count, reset = self._windows.get(key, (0, now + window))
            if now >= reset:
                count, reset = 0, now + window
            count += 1
            self._windows[key] = (count, reset)
        return count, max(1, math.ceil(reset - now))

    def reset(self) -> None:
        with self._lock:
            self._windows.clear()


class RedisStore:
    name = "redis"

    def __init__(self, client) -> None:
        self.client = client

    def hit(self, key: str, window: int) -> tuple[int, int]:
        now = time.time()
        bucket = int(now // window)
        k = f"rl:{key}:{bucket}"
        count = self.client.incr(k)
        if count == 1:
            self.client.expire(k, window + 1)
        return int(count), max(1, math.ceil((bucket + 1) * window - now))


_memory = MemoryStore()
_client = None  # Redis client; created lazily from REDIS_URL, or injected (tests)


def set_client(client) -> None:
    global _client
    _client = client


def _redis_store() -> RedisStore | None:
    global _client
    if _client is None and settings.redis_url:
        import redis
        _client = redis.Redis.from_url(settings.redis_url, socket_timeout=0.5, socket_connect_timeout=0.5)
    return RedisStore(_client) if _client is not None else None


def hit(key: str, window: int) -> tuple[int, int]:
    store = _redis_store()
    if store is not None:
        try:
            return store.hit(key, window)
        except Exception:
            log.warning("Redis unavailable for rate limiting; counting in-process instead", exc_info=True)
    return _memory.hit(key, window)


def backend_name() -> str:
    return "redis" if (settings.redis_url or _client is not None) else "memory"


def reset() -> None:
    _memory.reset()


def _human(seconds: int) -> str:
    if seconds < 90:
        return f"{seconds} seconds"
    if seconds < 5400:
        return f"{math.ceil(seconds / 60)} minutes"
    return f"{math.ceil(seconds / 3600)} hours"


def rate_limit(name: str):
    """FastAPI dependency: enforce settings.rl_<name> for the calling user. Returns 429 when exceeded."""

    def dependency(user_id: str = Depends(current_user_id)) -> None:
        if not settings.rate_limits_enabled:
            return
        limit, window = parse(getattr(settings, f"rl_{name}"))
        count, retry = hit(f"{name}:{user_id}", window)
        if count > limit:
            raise HTTPException(
                429,
                detail=f"Too many requests. Try again in {_human(retry)}.",
                headers={"Retry-After": str(retry), "RateLimit-Limit": str(limit),
                         "RateLimit-Remaining": "0", "RateLimit-Reset": str(retry)},
            )

    return dependency
