"""Finds clip-worthy moments in a transcript.

The LLM never picks timestamps. It picks whole sentences by id; start and end times come from the
sentence boundaries in the transcript, so clips begin and end on complete thoughts.
"""
import json
import math
import re
import time
from typing import Callable

import httpx

from .config import settings
from .errors import PipelineError

CATEGORIES = {"hook", "educational", "funny", "insight", "story", "opinion"}
_END = re.compile(r"[.!?][\"'”’)]*$")

SYSTEM = """You are an editor who cuts long videos into short clips for YouTube Shorts, Reels and TikTok.
You receive a transcript as numbered sentences with timestamps. Choose moments that would work as standalone clips.

Prefer: a strong opening line that makes a stranger keep watching, funny moments, teachable insights,
bold or important statements, and stories with a clear payoff.
Each clip must:
- start on a sentence that works as a hook without earlier context (not "and so", "like I said", or a reply to an unseen question)
- end on a sentence that completes the thought
- run {min}-{max} seconds, using the timestamps
- make sense on its own
Do not pick filler, small talk, sponsor reads, or setup that only pays off outside the clip.
Respond with JSON only, no other text:
{{"moments":[{{"start_id":int,"end_id":int,"title":"short title","category":"hook|educational|funny|insight|story|opinion","score":0-100,"reason":"one sentence on why this works"}}]}}
Score honestly: most moments are below 80. Return fewer moments rather than weak ones."""


def build_sentences(words: list[dict], gap: float = 0.9, max_words: int = 40) -> list[dict]:
    out: list[dict] = []
    cur: list[dict] = []

    def flush():
        if cur:
            out.append({"id": len(out), "start": cur[0]["start"], "end": cur[-1]["end"],
                        "text": " ".join(w["word"] for w in cur)})
            cur.clear()

    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if _END.search(w["word"]) or len(cur) >= max_words or (nxt and nxt["start"] - w["end"] > gap):
            flush()
    flush()
    return out


def windows(sents: list[dict], span: int = 1200, overlap: int = 120) -> list[list[dict]]:
    if not sents:
        return []
    t0, end, res = sents[0]["start"], sents[-1]["end"], []
    while True:
        chunk = [s for s in sents if t0 <= s["start"] < t0 + span]
        if chunk:
            res.append(chunk)
        if t0 + span >= end:
            return res
        t0 += span - overlap


def _fmt(t: float) -> str:
    return f"{int(t // 60)}:{int(t % 60):02d}"


def _parse(raw: str, by_id: dict[int, dict]) -> list[dict]:
    a, b = raw.find("{"), raw.rfind("}")
    if a < 0 or b < a:
        raise ValueError("no JSON object in response")
    items = json.loads(raw[a:b + 1]).get("moments", [])
    lo, hi = settings.clip_min_seconds, settings.clip_max_seconds
    out = []
    for m in items:
        try:
            s, e = by_id[int(m["start_id"])], by_id[int(m["end_id"])]
        except (KeyError, ValueError, TypeError):
            continue
        start, end = s["start"], e["end"]
        if end <= start or not (lo <= end - start <= hi):
            continue
        cat = str(m.get("category", "")).lower()
        try:
            score = max(0, min(100, int(m.get("score", 0))))
        except (ValueError, TypeError):
            score = 0
        out.append({"start_seconds": round(max(0.0, start - 0.15), 2), "end_seconds": round(end + 0.25, 2),
                    "title": str(m.get("title", ""))[:100] or "Untitled clip",
                    "category": cat if cat in CATEGORIES else "insight",
                    "score": score, "reason": str(m.get("reason", ""))[:300]})
    return out


def _select(cands: list[dict], k: int) -> list[dict]:
    chosen: list[dict] = []
    for c in sorted(cands, key=lambda c: c["score"], reverse=True):
        dur = c["end_seconds"] - c["start_seconds"]
        clash = any(
            max(0, min(c["end_seconds"], d["end_seconds"]) - max(c["start_seconds"], d["start_seconds"]))
            > 0.3 * min(dur, d["end_seconds"] - d["start_seconds"]) for d in chosen)
        if not clash:
            chosen.append(c)
        if len(chosen) == k:
            break
    return sorted(chosen, key=lambda c: c["start_seconds"])


def find_moments(words: list[dict], duration: float, llm: Callable[[str, str], str]) -> list[dict]:
    sents = build_sentences(words)
    by_id = {s["id"]: s for s in sents}
    wins = windows(sents)
    k = max(3, min(12, round(duration / 360)))
    per_window = math.ceil(k * 1.5 / max(1, len(wins))) + 1
    system = SYSTEM.format(min=settings.clip_min_seconds, max=settings.clip_max_seconds)
    cands, good = [], 0
    for w in wins:
        lines = "\n".join(f"[{s['id']}] {_fmt(s['start'])} {s['text']}" for s in w)
        try:
            cands += _parse(llm(system, f"Transcript:\n{lines}\n\nReturn at most {per_window} moments."), by_id)
            good += 1
        except (ValueError, KeyError, TypeError, AttributeError):
            continue
    if wins and good == 0:
        raise PipelineError("The AI returned an unreadable answer. Try again.")
    return _select(cands, k)


def anthropic_llm(system: str, user: str) -> str:
    if not settings.anthropic_key:
        raise PipelineError("AI analysis is not configured on the server (ANTHROPIC_API_KEY is missing).")
    for attempt in range(3):
        try:
            r = httpx.post("https://api.anthropic.com/v1/messages", timeout=120,
                           headers={"x-api-key": settings.anthropic_key, "anthropic-version": "2023-06-01"},
                           json={"model": settings.llm_model, "max_tokens": 2000, "system": system,
                                 "messages": [{"role": "user", "content": user}]})
        except httpx.HTTPError:
            r = None
        if r is not None and r.status_code == 200:
            return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text")
        if r is not None and r.status_code not in (429, 500, 502, 503, 529):
            raise PipelineError(f"AI analysis failed ({r.status_code}). Check the server's API key and model name.")
        time.sleep(2 ** attempt * 2)
    raise PipelineError("The AI service is busy or unreachable. Try again in a few minutes.")
