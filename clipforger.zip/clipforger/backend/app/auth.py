import httpx
from fastapi import Header, HTTPException

from .config import settings


def current_user_id(authorization: str | None = Header(default=None)) -> str:
    """Validate the caller's Supabase access token with Supabase itself and return their user id."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing access token.")
    try:
        r = httpx.get(f"{settings.url}/auth/v1/user", timeout=10,
                      headers={"apikey": settings.service_key, "Authorization": authorization})
    except httpx.HTTPError:
        raise HTTPException(503, "Could not reach the auth service.")
    if r.status_code != 200:
        raise HTTPException(401, "Invalid or expired session. Log in again.")
    return r.json()["id"]
