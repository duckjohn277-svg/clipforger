"""Builds ASS subtitle files from word-level timestamps.

ASS (libass) lets FFmpeg burn in styled, per-word animated captions at render time.
"""
import re

ACCENT = r"\c&HF65C8B&"    # violet #8b5cf6 (ASS colors are BGR)
KEYWORD = r"\c&H00E5FF&"   # yellow #ffe500
WHITE = r"\c&HFFFFFF&"
STOP = set("""about above after again against also because been before being below between both but could did does doing down
during each from further have having here hers herself himself into itself just like more most myself once only other ours
ourselves over same should some such than that their theirs them themselves then there these they this those through under
until very was were what when where which while who whom whose will with would your yours yourself yourselves really actually
gonna kind sort thing things know going think because people""".split())
STYLES = ("bold", "karaoke", "pop", "minimal")
_END = re.compile(r"[.!?,;:]$")


def _t(sec: float) -> str:
    cs = round(max(sec, 0) * 100)
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def _clean(w: str) -> str:
    return re.sub(r"[{}\\]", "", w)


def keyword_index(chunk: list[str]) -> int | None:
    """Index of the word worth emphasizing: a number, else the longest non-filler word of 5+ letters."""
    for i, w in enumerate(chunk):
        if any(c.isdigit() for c in w):
            return i
    best = None
    for i, w in enumerate(chunk):
        core = re.sub(r"\W", "", w).lower()
        if len(core) >= 5 and core not in STOP and (best is None or len(core) > len(re.sub(r"\W", "", chunk[best]))):
            best = i
    return best


def chunk_words(words: list[dict], max_words: int, gap: float = 0.6) -> list[list[dict]]:
    chunks, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        if len(cur) >= max_words or _END.search(w["word"]) or (nxt and nxt["start"] - w["end"] > gap):
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    return chunks


def generate_ass(words: list[dict], clip_start: float, clip_end: float, width: int, height: int, o: dict) -> str:
    dur = clip_end - clip_start
    ws = [{"start": min(max(w["start"] - clip_start, 0), dur), "end": min(max(w["end"] - clip_start, 0), dur),
           "word": _clean(w["word"])} for w in words if w["end"] > clip_start and w["start"] < clip_end and _clean(w["word"])]
    style = o["style"]
    short = min(width, height)
    size = round(short * o["font_size_pct"] / 100)
    pos = o["position"]
    align = {"top": 8, "middle": 5, "bottom": 2}[pos]
    margin_v = 0 if pos == "middle" else round(height * o["offset_pct"] / 100)
    boxed = style == "minimal"
    outline = 0 if boxed else max(2, round(size * 0.07))
    back = "&H99000000" if boxed else "&H00000000"
    font = "Montserrat SemiBold" if boxed else "Anton"
    head = (
        f"[Script Info]\nScriptType: v4.00+\nPlayResX: {width}\nPlayResY: {height}\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n"
        "[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,"
        "Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
        f"Style: Default,{font},{size},&H00FFFFFF,&H00FFFFFF,&H00000000,{back},0,0,0,0,100,100,0,0,"
        f"{3 if boxed else 1},{outline},0,{align},{round(width * 0.07)},{round(width * 0.07)},{margin_v},1\n\n"
        "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n")

    max_words = {"bold": 4, "karaoke": 4, "pop": 1, "minimal": 7}[style]
    chunks = chunk_words(ws, max_words)
    lines = []

    def text(chunk, active=None):
        kw = keyword_index([c["word"] for c in chunk]) if o["highlight_keywords"] and style != "pop" else None
        parts = []
        for i, c in enumerate(chunk):
            word = c["word"] if style == "minimal" else c["word"].upper()
            color = ACCENT if i == active else KEYWORD if i == kw else WHITE
            parts.append(f"{{{color}}}{word}")
        return " ".join(parts)

    for ci, chunk in enumerate(chunks):
        start, end = chunk[0]["start"], chunk[-1]["end"]
        nxt = chunks[ci + 1][0]["start"] if ci + 1 < len(chunks) else None
        if nxt is not None and 0 <= nxt - end < 0.3:
            end = nxt  # avoid flicker between chunks
        end = max(end, start + 0.12)
        if style == "karaoke":
            for i, c in enumerate(chunk):
                s = c["start"] if i else start
                e = chunk[i + 1]["start"] if i + 1 < len(chunk) else end
                lines.append(f"Dialogue: 0,{_t(s)},{_t(max(e, s + 0.05))},Default,,0,0,0,,{text(chunk, i)}")
        elif style == "pop":
            pop = r"{\fscx60\fscy60\t(0,90,\fscx115\fscy115)\t(90,170,\fscx100\fscy100)}"
            kw = o["highlight_keywords"] and keyword_index([chunk[0]["word"]]) == 0
            color = KEYWORD if kw else WHITE
            lines.append(f"Dialogue: 0,{_t(start)},{_t(end)},Default,,0,0,0,,{pop}{{{color}}}{chunk[0]['word'].upper()}")
        else:
            lines.append(f"Dialogue: 0,{_t(start)},{_t(end)},Default,,0,0,0,,{text(chunk)}")
    return head + "\n".join(lines) + "\n"
