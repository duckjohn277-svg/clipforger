import logging
import os
import shutil
import tempfile

from . import db, jobs, media, moments, recovery, transcribe
from .config import settings
from .errors import PipelineError

log = logging.getLogger("clipforger.pipeline")


def run(project_id: str) -> None:
    """Download -> extract audio -> transcribe -> find moments. Never raises; failures are written to the project.
    If audio was already extracted (earlier run failed later), resumes from the stored audio.
    If the project is deleted while this runs, it stops at the next checkpoint without writing anything."""
    work = tempfile.mkdtemp(prefix="clipforger-")
    try:
        with recovery.heartbeat("projects", [project_id]):
            _process(project_id, work)
    except jobs.Cancelled:
        log.info("Processing stopped: project %s was deleted", project_id)
    except PipelineError as e:
        db.update_project(project_id, status="failed", error_message=str(e))
    except Exception:
        log.exception("Processing failed for project %s", project_id)
        db.update_project(project_id, status="failed", error_message="Something went wrong while processing. Try again.")
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _process(project_id: str, work: str) -> None:
    step = lambda s: db.update_project(project_id, processing_step=s)
    jobs.checkpoint(project_id)
    p = db.get_project(project_id)
    if not p or not p.get("storage_path"):
        raise PipelineError("The uploaded video could not be found.")
    uid, audio = p["user_id"], os.path.join(work, "audio.mp3")
    duration = p.get("duration_seconds") or 0

    if p.get("audio_path"):
        step("downloading")
        db.download_audio(p["audio_path"], audio)
    else:
        if (p.get("size_bytes") or 0) > settings.max_upload_mb * 1024 * 1024:
            raise PipelineError(f"This file is over the {settings.max_upload_mb} MB limit.")
        step("downloading")
        src = os.path.join(work, "input" + os.path.splitext(p["storage_path"])[1])
        db.download_video(p["storage_path"], src)
        jobs.checkpoint(project_id)
        step("probing")
        duration = media.probe(src)["duration"]
        if duration > settings.max_video_minutes * 60:
            raise PipelineError(f"This video is longer than the {settings.max_video_minutes}-minute limit.")
        db.update_project(project_id, duration_seconds=duration)
        step("extracting_audio")
        media.extract_audio(src, audio, duration)
        jobs.checkpoint(project_id)
        step("saving_audio")
        audio_path = f"{uid}/{project_id}.mp3"
        db.upload_audio(audio_path, audio)
        jobs.guard_upload(project_id, "audio", audio_path)
        db.update_project(project_id, audio_path=audio_path)

    jobs.checkpoint(project_id)
    step("transcribing")
    tr = transcribe.transcribe(audio)
    jobs.checkpoint(project_id)
    db.save_transcript(project_id, uid, tr["language"], tr["segments"], tr["words"])

    step("finding_moments")
    found = moments.find_moments(tr["words"], duration or tr["words"][-1]["end"], moments.anthropic_llm)
    jobs.checkpoint(project_id)
    db.replace_clips(project_id, uid, found)
    db.update_project(project_id, status="ready", processing_step="done", error_message=None)
