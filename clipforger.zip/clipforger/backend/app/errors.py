class PipelineError(Exception):
    """A failure whose message is safe and useful to show to the user."""
