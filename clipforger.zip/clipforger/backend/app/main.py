import logging
import shutil
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Literal
from uuid import UUID

from fastapi import Depends, FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, model_validator

from . import cleanup, db, jobs, pipeline, ratelimit, recovery, render
from .auth import current_user_id
from .config import settings

log = logging.getLogger("clipforger")
executor = ThreadPoolExecutor(max_workers=settings.workers)


@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.missing():
        log.error("Missing environment variables: %s", ", ".join(settings.missing()))
    else:
        # Stale jobs are recovered from expired leases, not by failing everything at startup.
        # That keeps this instance from breaking jobs that another instance is still running.
        recovery.start_background()
    yield
    executor.shutdown(wait=False, cancel_futures=True)


app = FastAPI(title="Clipforger AI API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.frontend_origins,
                   allow_origin_regex=settings.frontend_origin_regex,
                   allow_methods=["GET", "POST", "DELETE"], allow_headers=["Authorization", "Content-Type"])


@app.get("/health")
def health(response: Response) -> dict:
    """Liveness for load balancers and Docker. Returns 503 when FFmpeg is missing, since no clip can be made."""
    ffmpeg = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
    if not ffmpeg:
        response.status_code = 503
    return {"status": "ok" if ffmpeg else "degraded", "ffmpeg": ffmpeg,
            "configured": not settings.missing(), "rate_limit_store": ratelimit.backend_name()}


def _owned(project_id: str, user_id: str) -> dict:
    p = db.get_project(project_id)
    if not p or p["user_id"] != user_id:  # 404 for other people's projects too, so ids cannot be probed
        raise HTTPException(404, "Project not found.")
    return p


@app.post("/projects/{project_id}/process", status_code=202, dependencies=[Depends(ratelimit.rate_limit("process"))])
def start_processing(project_id: str, user_id: str = Depends(current_user_id)) -> dict:
    _owned(project_id, user_id)
    if not db.claim_project(project_id):
        raise HTTPException(409, "This project is already processing or has already been processed.")
    jobs.track(project_id, executor.submit(pipeline.run, project_id))
    return {"status": "processing"}


@app.get("/projects/{project_id}", dependencies=[Depends(ratelimit.rate_limit("read"))])
def project_status(project_id: str, user_id: str = Depends(current_user_id)) -> dict:
    p = _owned(project_id, user_id)
    return {k: p.get(k) for k in ("id", "status", "processing_step", "error_message", "duration_seconds")}


@app.delete("/projects/{project_id}", dependencies=[Depends(ratelimit.rate_limit("delete"))])
def delete_project(project_id: str, user_id: str = Depends(current_user_id)) -> dict:
    """Delete a project, its clips, transcript and every stored file. Safe to retry."""
    _owned(project_id, user_id)
    result = cleanup.delete_project(project_id, user_id)
    if not result["deleted"]:
        raise HTTPException(404, "Project not found.")
    return {"id": project_id, **result}


class Captions(BaseModel):
    enabled: bool = True
    style: Literal["bold", "karaoke", "pop", "minimal"] = "karaoke"
    font_size_pct: float = Field(9, ge=4, le=16)  # percent of the short side of the output
    position: Literal["top", "middle", "bottom"] = "bottom"
    offset_pct: float = Field(14, ge=0, le=40)  # distance from the top/bottom edge, percent of height
    highlight_keywords: bool = True


class RenderRequest(BaseModel):
    clip_ids: list[UUID] | None = None  # None = every clip in the project
    aspect: Literal["9:16", "1:1", "16:9"] = "9:16"
    fit: Literal["fill", "blur"] = "fill"
    captions: Captions = Captions()
    start_seconds: float | None = Field(None, ge=0)  # trim: applies to exactly one clip
    end_seconds: float | None = Field(None, ge=0)

    @model_validator(mode="after")
    def _check_trim(self):
        if (self.start_seconds is None) != (self.end_seconds is None):
            raise ValueError("start_seconds and end_seconds must be sent together.")
        if self.start_seconds is not None:
            if not self.clip_ids or len(self.clip_ids) != 1:
                raise ValueError("A trim applies to exactly one clip.")
            if not 3 <= self.end_seconds - self.start_seconds <= 180:
                raise ValueError("Clips must be between 3 and 180 seconds long.")
        return self


@app.post("/projects/{project_id}/render", status_code=202, dependencies=[Depends(ratelimit.rate_limit("render"))])
def render_clips(project_id: str, req: RenderRequest, user_id: str = Depends(current_user_id)) -> dict:
    p = _owned(project_id, user_id)
    if p["status"] != "ready":
        raise HTTPException(409, "Analyze this video before rendering clips.")
    if req.end_seconds is not None and p.get("duration_seconds") and req.end_seconds > p["duration_seconds"] + 0.5:
        raise HTTPException(422, "The end time is past the end of the video.")
    claimed = db.claim_clips(project_id, [str(c) for c in req.clip_ids] if req.clip_ids else None)
    if not claimed:
        raise HTTPException(409, "These clips are already rendering, or no matching clips were found.")
    if req.start_seconds is not None:
        db.update_clip(claimed[0]["id"], start_seconds=req.start_seconds, end_seconds=req.end_seconds)
    jobs.track(project_id, executor.submit(render.render_job, project_id, [c["id"] for c in claimed], req.model_dump(mode="json")))
    return {"queued": len(claimed)}


@app.get("/projects/{project_id}/clips", dependencies=[Depends(ratelimit.rate_limit("read"))])
def list_clips(project_id: str, user_id: str = Depends(current_user_id)) -> list[dict]:
    _owned(project_id, user_id)
    keys = ("id", "render_status", "render_error", "output_path")
    return [{k: c.get(k) for k in keys} for c in db.get_clips(project_id)]


@app.get("/projects/{project_id}/words", dependencies=[Depends(ratelimit.rate_limit("read"))])
def words_in_range(project_id: str, start: float = 0, end: float = 1e9, user_id: str = Depends(current_user_id)) -> list[dict]:
    _owned(project_id, user_id)
    if end - start > 600:
        raise HTTPException(422, "Range too large.")
    return [{"start": w["start"], "end": w["end"], "word": w["word"]}
            for w in db.get_transcript_words(project_id) if w["end"] > start and w["start"] < end]
