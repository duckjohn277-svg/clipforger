"""Project deletion and storage cleanup.

Deletion order matters: database rows go first (the triggers in migration 007 have already queued
every file), then files. A file is only removed after its row is gone, so nothing live is deleted,
and anything left behind is retried from the queue."""
import logging
from collections import defaultdict

from . import db, jobs

log = logging.getLogger("clipforger.cleanup")


def _purge(rows: list[dict]) -> dict:
    alive: dict[str, bool] = {}

    def project_alive(pid: str) -> bool:
        if pid not in alive:
            alive[pid] = db.project_exists(pid)
        return alive[pid]

    by_bucket: dict[str, list[dict]] = defaultdict(list)
    skipped = 0
    for row in rows:
        # Source media of a project that still exists is never deleted from the queue. Only
        # rendered clips can be orphaned while their project lives (re-analysis replaces clip rows).
        if row["bucket"] != "clips" and project_alive(row["project_id"]):
            skipped += 1
            log.warning("Skipping queued %s/%s: its project still exists", row["bucket"], row["path"])
            continue
        by_bucket[row["bucket"]].append(row)

    done, failed = [], 0
    for bucket, group in by_bucket.items():
        try:
            db.delete_objects(bucket, [r["path"] for r in group])
            done.extend(r["id"] for r in group)
        except Exception as e:
            failed += len(group)
            log.exception("Storage delete failed for %d object(s) in %s", len(group), bucket)
            for r in group:
                db.mark_cleanup_failed(r, str(e))
    db.delete_cleanup_rows(done)
    return {"deleted": len(done), "failed": failed, "skipped": skipped}


def sweep(limit: int = 200) -> dict:
    """Process the storage cleanup queue (called periodically by the maintenance thread)."""
    rows = db.cleanup_rows(limit)
    return _purge(rows) if rows else {"deleted": 0, "failed": 0, "skipped": 0}


def delete_project(project_id: str, user_id: str) -> dict:
    """Delete a project and everything it owns. Caller must already have verified ownership.
    Returns False if nothing was deleted (the project was already gone)."""
    jobs.cancel(project_id)
    if db.delete_project_row(project_id, user_id) == 0:
        return {"deleted": False}
    try:
        storage = _purge(db.cleanup_rows(500, project_id=project_id))
    except Exception:
        # Rows are gone and the queue has the files, so the maintenance thread will finish the job.
        log.exception("Immediate storage cleanup failed for project %s; the queue will retry", project_id)
        storage = {"pending": True}
    return {"deleted": True, "storage": storage}
