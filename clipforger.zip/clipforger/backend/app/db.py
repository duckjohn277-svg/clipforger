"""Thin Supabase REST/Storage client. Uses the service-role key: backend only, never the frontend."""
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import httpx

from .config import settings

_http = httpx.Client(timeout=30)


def _auth() -> dict[str, str]:
    return {"apikey": settings.service_key, "Authorization": f"Bearer {settings.service_key}"}


def utc_iso(offset_seconds: float = 0) -> str:
    """ISO-8601 UTC timestamp, offset from now. Uses 'Z' so it is safe in PostgREST filter strings."""
    return (datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)).isoformat().replace("+00:00", "Z")


def _table(name: str, params: dict, method: str = "GET", **kw) -> httpx.Response:
    return _http.request(method, f"{settings.url}/rest/v1/{name}", params=params, **kw)


def _projects(params: dict, **kw) -> httpx.Response:
    return _table("projects", params, kw.pop("method", "GET"), **kw)


def _clips(params: dict, method: str = "GET", **kw) -> httpx.Response:
    r = _table("clips", params, method, **kw)
    r.raise_for_status()
    return r


# ---- projects -----------------------------------------------------------------------------

def get_project(pid: str) -> dict | None:
    r = _projects({"id": f"eq.{pid}", "select": "*"}, headers=_auth())
    r.raise_for_status()
    rows = r.json()
    return rows[0] if rows else None


def project_exists(pid: str) -> bool:
    r = _projects({"id": f"eq.{pid}", "select": "id"}, headers=_auth())
    r.raise_for_status()
    return bool(r.json())


def update_project(pid: str, **fields) -> None:
    r = _projects({"id": f"eq.{pid}"}, method="PATCH", json=fields,
                  headers={**_auth(), "Prefer": "return=minimal"})
    r.raise_for_status()


def claim_project(pid: str) -> bool:
    """Atomically move uploaded/failed/audio_ready -> processing. False if someone else already claimed it.
    The lease covers the time the job may wait in the worker pool before it starts."""
    r = _projects({"id": f"eq.{pid}", "status": "in.(uploaded,failed,audio_ready)"}, method="PATCH",
                  json={"status": "processing", "processing_step": "queued", "error_message": None,
                        "locked_until": utc_iso(settings.queue_grace_seconds)},
                  headers={**_auth(), "Prefer": "return=representation"})
    r.raise_for_status()
    return len(r.json()) == 1


def delete_project_row(pid: str, user_id: str) -> int:
    """Delete one project owned by user_id. Clips and transcripts cascade; the triggers in migration 007
    queue the project's files for storage cleanup. Returns the number of rows removed (0 or 1)."""
    r = _projects({"id": f"eq.{pid}", "user_id": f"eq.{user_id}"}, method="DELETE",
                  headers={**_auth(), "Prefer": "return=representation"})
    r.raise_for_status()
    return len(r.json())


def fail_stale_projects(message: str) -> int:
    """Recover jobs whose lease expired (worker died). Returns how many were marked failed."""
    now = utc_iso()
    r = _projects({"status": "eq.processing", "or": f"(locked_until.lt.{now},locked_until.is.null)"},
                  method="PATCH",
                  json={"status": "failed", "error_message": message, "locked_until": None},
                  headers={**_auth(), "Prefer": "return=representation"})
    r.raise_for_status()
    return len(r.json())


# ---- leases -------------------------------------------------------------------------------

def touch(table: str, ids: list[str], until: str) -> None:
    """Renew the lease on projects or clips rows."""
    if not ids:
        return
    r = _table(table, {"id": f"in.({','.join(ids)})"}, "PATCH", json={"locked_until": until},
               headers={**_auth(), "Prefer": "return=minimal"})
    r.raise_for_status()


# ---- transcripts and clips ----------------------------------------------------------------

def save_transcript(pid: str, user_id: str, language: str, segments: list, words: list) -> None:
    r = _http.post(f"{settings.url}/rest/v1/transcripts", params={"on_conflict": "project_id"}, timeout=120,
                   headers={**_auth(), "Prefer": "resolution=merge-duplicates,return=minimal"},
                   json={"project_id": pid, "user_id": user_id, "language": language, "segments": segments, "words": words})
    r.raise_for_status()


def replace_clips(pid: str, user_id: str, clips: list[dict]) -> None:
    _http.delete(f"{settings.url}/rest/v1/clips", params={"project_id": f"eq.{pid}"}, headers=_auth()).raise_for_status()
    if clips:
        rows = [{**c, "project_id": pid, "user_id": user_id} for c in clips]
        _http.post(f"{settings.url}/rest/v1/clips", json=rows,
                   headers={**_auth(), "Prefer": "return=minimal"}).raise_for_status()


def get_clips(pid: str) -> list[dict]:
    return _clips({"project_id": f"eq.{pid}", "select": "*", "order": "start_seconds"}, headers=_auth()).json()


def clip_exists(cid: str) -> bool:
    return bool(_clips({"id": f"eq.{cid}", "select": "id"}, headers=_auth()).json())


def get_transcript_words(pid: str) -> list[dict]:
    r = _http.get(f"{settings.url}/rest/v1/transcripts", params={"project_id": f"eq.{pid}", "select": "words"}, headers=_auth(), timeout=120)
    r.raise_for_status()
    rows = r.json()
    return rows[0]["words"] if rows else []


def claim_clips(pid: str, clip_ids: list[str] | None) -> list[dict]:
    """Atomically mark clips queued, skipping any already queued or rendering. Returns the clips claimed."""
    params = {"project_id": f"eq.{pid}", "render_status": "not.in.(queued,rendering)"}
    if clip_ids:
        params["id"] = f"in.({','.join(clip_ids)})"
    return _clips(params, "PATCH",
                  json={"render_status": "queued", "render_error": None, "locked_until": utc_iso(settings.queue_grace_seconds)},
                  headers={**_auth(), "Prefer": "return=representation"}).json()


def update_clip(cid: str, **fields) -> None:
    _clips({"id": f"eq.{cid}"}, "PATCH", json=fields, headers={**_auth(), "Prefer": "return=minimal"})


def fail_stale_clips(message: str) -> int:
    now = utc_iso()
    r = _clips({"render_status": "in.(queued,rendering)", "or": f"(locked_until.lt.{now},locked_until.is.null)"},
               "PATCH", json={"render_status": "failed", "render_error": message, "locked_until": None},
               headers={**_auth(), "Prefer": "return=representation"})
    return len(r.json())


# ---- storage ------------------------------------------------------------------------------

def download_video(path: str, dest: str) -> None:
    with httpx.stream("GET", f"{settings.url}/storage/v1/object/videos/{quote(path)}",
                      headers=_auth(), timeout=None) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(1 << 20):
                f.write(chunk)


def upload_audio(path: str, file_path: str) -> None:
    with open(file_path, "rb") as f:
        r = httpx.post(f"{settings.url}/storage/v1/object/audio/{quote(path)}",
                       headers={**_auth(), "Content-Type": "audio/mpeg", "x-upsert": "true"},
                       content=f.read(), timeout=300)
    r.raise_for_status()


def download_audio(path: str, dest: str) -> None:
    with httpx.stream("GET", f"{settings.url}/storage/v1/object/audio/{quote(path)}",
                      headers=_auth(), timeout=None) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(1 << 20):
                f.write(chunk)


def upload_clip(path: str, file_path: str) -> None:
    with open(file_path, "rb") as f:
        r = httpx.post(f"{settings.url}/storage/v1/object/clips/{quote(path)}",
                       headers={**_auth(), "Content-Type": "video/mp4", "x-upsert": "true"}, content=f.read(), timeout=600)
    r.raise_for_status()


def delete_objects(bucket: str, paths: list[str]) -> None:
    """Bulk-delete objects. Missing objects are not an error."""
    if not paths:
        return
    r = _http.request("DELETE", f"{settings.url}/storage/v1/object/{bucket}", json={"prefixes": paths},
                      headers=_auth(), timeout=60)
    r.raise_for_status()


def enqueue_cleanup(bucket: str, path: str, project_id: str, user_id: str) -> None:
    """Record a file for later deletion (used when an immediate delete fails)."""
    r = _http.post(f"{settings.url}/rest/v1/storage_cleanup", params={"on_conflict": "bucket,path"}, timeout=30,
                   headers={**_auth(), "Prefer": "resolution=ignore-duplicates,return=minimal"},
                   json={"bucket": bucket, "path": path, "project_id": project_id, "user_id": user_id})
    r.raise_for_status()


# ---- storage cleanup queue ----------------------------------------------------------------

def cleanup_rows(limit: int = 200, project_id: str | None = None) -> list[dict]:
    params = {"select": "*", "order": "attempts.asc,id.asc", "limit": str(limit)}
    if project_id:
        params["project_id"] = f"eq.{project_id}"
    r = _table("storage_cleanup", params, headers=_auth())
    r.raise_for_status()
    return r.json()


def delete_cleanup_rows(ids: list[int]) -> None:
    if not ids:
        return
    r = _table("storage_cleanup", {"id": f"in.({','.join(str(i) for i in ids)})"}, "DELETE",
               headers={**_auth(), "Prefer": "return=minimal"})
    r.raise_for_status()


def mark_cleanup_failed(row: dict, message: str) -> None:
    r = _table("storage_cleanup", {"id": f"eq.{row['id']}"}, "PATCH",
               json={"attempts": int(row.get("attempts") or 0) + 1, "last_error": message[:500]},
               headers={**_auth(), "Prefer": "return=minimal"})
    r.raise_for_status()
