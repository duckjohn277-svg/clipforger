import os
from dotenv import load_dotenv

load_dotenv()


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, str(default)))


class Settings:
    url = os.environ.get("SUPABASE_URL", "").rstrip("/")
    service_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    # Comma-separated list of exact origins, e.g. "https://app.example.com,https://www.example.com".
    frontend_origin = os.environ.get("FRONTEND_ORIGIN", "http://localhost:3000")
    frontend_origins = [o.strip().rstrip("/") for o in frontend_origin.split(",") if o.strip()]
    # Optional regex for origins that change per deployment, e.g. Vercel previews:
    # ^https://clipforger-[a-z0-9-]+-your-team\.vercel\.app$
    frontend_origin_regex = os.environ.get("FRONTEND_ORIGIN_REGEX", "") or None
    workers = int(os.environ.get("PROCESSING_WORKERS", "2"))
    max_upload_mb = int(os.environ.get("MAX_UPLOAD_MB", "500"))
    max_video_minutes = int(os.environ.get("MAX_VIDEO_MINUTES", "240"))

    whisper_model = os.environ.get("WHISPER_MODEL", "small")
    whisper_device = os.environ.get("WHISPER_DEVICE", "auto")
    whisper_compute = os.environ.get("WHISPER_COMPUTE_TYPE", "int8")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    llm_model = os.environ.get("LLM_MODEL", "claude-sonnet-5-5")
    clip_min_seconds = int(os.environ.get("CLIP_MIN_SECONDS", "20"))
    clip_max_seconds = int(os.environ.get("CLIP_MAX_SECONDS", "90"))

    # Rate limits, "count/unit" with unit second|minute|hour|day. Per authenticated user.
    rate_limits_enabled = os.environ.get("RATE_LIMITS_ENABLED", "true").lower() not in ("0", "false", "no")
    rl_process = os.environ.get("RATE_LIMIT_PROCESS", "10/hour")  # starting analysis
    rl_render = os.environ.get("RATE_LIMIT_RENDER", "60/hour")    # rendering clips
    rl_delete = os.environ.get("RATE_LIMIT_DELETE", "30/hour")
    rl_read = os.environ.get("RATE_LIMIT_READ", "600/minute")    # status polling and listings
    redis_url = os.environ.get("REDIS_URL", "")                  # shared limits across instances; empty = in-process

    # Job leases. A running job renews its lease every heartbeat_seconds; a lease that
    # expires means the worker died, and the job is recovered as failed.
    job_lease_seconds = _int("JOB_LEASE_SECONDS", 600)
    queue_grace_seconds = _int("QUEUE_GRACE_SECONDS", 1800)      # time a job may wait in the pool before it starts
    heartbeat_seconds = _int("HEARTBEAT_SECONDS", 60)
    maintenance_seconds = _int("MAINTENANCE_SECONDS", 60)        # how often stale jobs are reaped and cleanup runs

    def missing(self) -> list[str]:
        return [n for n, v in (("SUPABASE_URL", self.url), ("SUPABASE_SERVICE_ROLE_KEY", self.service_key)) if not v]


settings = Settings()
