import shutil
import subprocess

import pytest

from app import moments, ratelimit, transcribe
from app.config import settings
from fake_supabase import FakeSupabase
from helpers import fake_llm, fake_transcribe

HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
ffmpeg_required = pytest.mark.skipif(not HAS_FFMPEG, reason="ffmpeg not installed")


@pytest.fixture(autouse=True)
def _fresh_rate_limits():
    ratelimit.reset()
    yield
    ratelimit.reset()


@pytest.fixture()
def supa(monkeypatch):
    """A fake Supabase server; the backend's settings point at it for the duration of the test."""
    fake = FakeSupabase()
    base = fake.start()
    monkeypatch.setattr(settings, "url", base)
    monkeypatch.setattr(settings, "service_key", "service-key")
    yield fake
    fake.stop()


@pytest.fixture()
def pipeline_stubs(monkeypatch):
    """Replace only the two AI calls. FFmpeg, storage, HTTP and the database run for real."""
    monkeypatch.setattr(transcribe, "transcribe", fake_transcribe)
    monkeypatch.setattr(moments, "anthropic_llm", fake_llm)


@pytest.fixture(scope="session")
def video_bytes(tmp_path_factory) -> bytes:
    """A 60 s 320x240 clip with a tone, so audio extraction and rendering run for real."""
    if not HAS_FFMPEG:
        pytest.skip("ffmpeg not installed")
    path = tmp_path_factory.mktemp("media") / "talk.mp4"
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc=duration=60:size=320x240:rate=15",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=60", "-shortest",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", str(path)], check=True, capture_output=True)
    return path.read_bytes()
