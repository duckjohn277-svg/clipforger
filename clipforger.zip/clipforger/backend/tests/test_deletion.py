"""Project deletion and storage cleanup: no orphaned files, no stray deletes, cancelled jobs, retries."""
import concurrent.futures
import threading

import pytest
from fastapi.testclient import TestClient

from app import cleanup, db, jobs, main, pipeline, render, transcribe
from conftest import ffmpeg_required

TOKEN, OTHER = "owner-token", "other-token"


def auth(token=TOKEN) -> dict:
    return {"Authorization": f"Bearer {token}"}


def make_full_project(supa, uid: str):
    """A project with every kind of file: source video, extracted audio, transcript, and a rendered clip."""
    pid, video_path = supa.create_project(uid, b"video")
    audio_path = f"{uid}/{pid}.mp3"
    supa.put_object("audio", audio_path, b"mp3")
    supa.set_row("projects", pid, status="ready", audio_path=audio_path)
    supa.tables["transcripts"][pid] = {"project_id": pid, "user_id": uid, "words": [], "segments": []}
    cid = "22222222-2222-2222-2222-222222222222"
    out = f"{uid}/{pid}/{cid}.mp4"
    supa.put_object("clips", out, b"mp4")
    supa.tables["clips"][cid] = {"id": cid, "project_id": pid, "user_id": uid, "start_seconds": 0, "end_seconds": 25,
                                 "render_status": "done", "output_path": out}
    return pid, video_path, audio_path, out


def test_delete_removes_rows_and_every_file(supa):
    client = TestClient(main.app)
    uid = supa.add_user(TOKEN)
    pid, video_path, audio_path, out = make_full_project(supa, uid)
    res = client.delete(f"/projects/{pid}", headers=auth())
    assert res.status_code == 200
    assert supa.row("projects", pid) is None
    assert supa.tables["clips"] == {} and pid not in supa.tables["transcripts"]
    assert not supa.has_object("videos", video_path)
    assert not supa.has_object("audio", audio_path)
    assert not supa.has_object("clips", out)
    assert supa.cleanup_queue() == []


def test_only_the_owner_can_delete(supa):
    client = TestClient(main.app)
    uid = supa.add_user(TOKEN)
    supa.add_user(OTHER)
    pid, video_path, audio_path, out = make_full_project(supa, uid)
    assert client.delete(f"/projects/{pid}", headers=auth(OTHER)).status_code == 404
    assert client.delete(f"/projects/{pid}").status_code == 401
    assert supa.row("projects", pid) is not None
    assert supa.has_object("videos", video_path) and supa.has_object("clips", out)


def test_delete_is_idempotent(supa):
    client = TestClient(main.app)
    uid = supa.add_user(TOKEN)
    pid, *_ = make_full_project(supa, uid)
    assert client.delete(f"/projects/{pid}", headers=auth()).status_code == 200
    assert client.delete(f"/projects/{pid}", headers=auth()).status_code == 404


def test_failed_storage_delete_is_retried_by_the_queue(supa, monkeypatch):
    uid = supa.add_user(TOKEN)
    pid, video_path, *_ = make_full_project(supa, uid)
    real = db.delete_objects

    def flaky(bucket, paths):
        raise RuntimeError("storage unavailable")

    monkeypatch.setattr(db, "delete_objects", flaky)
    result = cleanup.delete_project(pid, uid)
    assert result["deleted"] is True and result["storage"]["failed"] > 0
    queued = [r for r in supa.cleanup_queue() if r["path"] == video_path]
    assert queued and queued[0]["attempts"] == 1 and "storage unavailable" in queued[0]["last_error"]

    monkeypatch.setattr(db, "delete_objects", real)
    cleanup.sweep()
    assert not supa.has_object("videos", video_path)
    assert supa.cleanup_queue() == []


def test_sweep_never_deletes_source_media_of_a_live_project(supa):
    uid = supa.add_user(TOKEN)
    pid, video_path = supa.create_project(uid, b"video")
    supa.put_object("videos", video_path)
    supa._enqueue("videos", video_path, pid, uid)  # a stale queue entry for a project that still exists
    cleanup.sweep()
    assert supa.has_object("videos", video_path)
    assert supa.row("projects", pid) is not None


def test_sweep_removes_orphaned_rendered_clips_of_a_live_project(supa):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"video")
    old = f"{uid}/{pid}/old-clip.mp4"
    supa.put_object("clips", old)
    supa._enqueue("clips", old, pid, uid)  # left behind by a re-analysis that replaced the clip rows
    cleanup.sweep()
    assert not supa.has_object("clips", old)


def test_upload_that_finishes_after_deletion_is_removed(supa):
    uid = supa.add_user(TOKEN)
    pid, video_path = supa.create_project(uid, b"video")
    path = f"{uid}/{pid}.mp3"
    supa.put_object("audio", path)          # the worker just finished uploading
    supa.tables["projects"].pop(pid)        # ...and the project was deleted before the guard ran
    with pytest.raises(jobs.Cancelled):
        jobs.guard_upload(pid, "audio", path)
    assert not supa.has_object("audio", path)


def test_guard_keeps_upload_for_a_live_project(supa):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"video")
    path = f"{uid}/{pid}.mp3"
    supa.put_object("audio", path)
    jobs.guard_upload(pid, "audio", path)   # no exception
    assert supa.has_object("audio", path)


def test_running_job_stops_quietly_after_its_project_is_deleted(supa, pipeline_stubs):
    uid = supa.add_user(TOKEN)
    pid, video_path = supa.create_project(uid, b"video")
    supa.tables["projects"].pop(pid)  # deleted before the job reached its first checkpoint
    pipeline.run(pid)                 # must not raise, must not write anything
    assert not supa.has_object("audio", f"{uid}/{pid}.mp3")


@ffmpeg_required
def test_render_in_flight_during_delete_leaves_no_orphan(supa, pipeline_stubs, video_bytes, monkeypatch):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, video_bytes)
    pipeline.run(pid)  # analyse synchronously so there are clip rows to render
    cid = next(iter(supa.tables["clips"]))
    supa.set_row("clips", cid, render_status="queued")

    real_render = render.render_clip

    def render_then_user_deletes(*args, **kwargs):
        real_render(*args, **kwargs)                 # FFmpeg finished writing the file...
        cleanup.delete_project(pid, uid)             # ...then the user deletes the project

    monkeypatch.setattr(render, "render_clip", render_then_user_deletes)
    render.render_job(pid, [cid], {"aspect": "9:16", "fit": "fill",
                                   "captions": {"enabled": False, "style": "karaoke", "font_size_pct": 9,
                                                "position": "bottom", "offset_pct": 14, "highlight_keywords": True}})
    assert supa.row("projects", pid) is None
    assert supa.objects_for(f"{uid}/{pid}") == []   # the upload that landed after the delete was removed
    assert supa.cleanup_queue() == []


def test_transcription_interrupted_by_delete_saves_nothing(supa, pipeline_stubs, video_bytes, monkeypatch):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"video")
    audio_path = f"{uid}/{pid}.mp3"          # audio already extracted, so the job goes straight to transcription
    supa.put_object("audio", audio_path, b"mp3")
    supa.set_row("projects", pid, audio_path=audio_path)
    from helpers import fake_transcribe

    def transcribe_then_user_deletes(audio_path):
        result = fake_transcribe(audio_path)
        cleanup.delete_project(pid, uid)
        return result

    monkeypatch.setattr(transcribe, "transcribe", transcribe_then_user_deletes)
    pipeline.run(pid)  # the checkpoint after transcription must stop the job before anything is saved
    assert pid not in supa.tables["transcripts"]
    assert supa.row("projects", pid) is None
    assert supa.cleanup_queue() == []  # the immediate purge ran after the row was removed


def test_queued_jobs_are_cancelled_on_delete():
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    gate = threading.Event()
    try:
        pool.submit(gate.wait, 5)          # occupy the only worker
        queued = pool.submit(lambda: "ran")
        jobs.track("project-x", queued)
        assert jobs.cancel("project-x") == 1
        assert queued.cancelled()
    finally:
        gate.set()
        pool.shutdown(wait=True)
