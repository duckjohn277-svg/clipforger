"""End-to-end workflow through the real HTTP API: auth, project creation, upload, processing,
clip generation, FFmpeg rendering, preview data, export, error handling and deletion.
Only the two AI calls are stubbed (see conftest.pipeline_stubs)."""
from fastapi.testclient import TestClient

from app import main
from conftest import ffmpeg_required
from helpers import probe_size, wait_clip, wait_status

ALICE, BOB = "alice-token", "bob-token"


def auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


@ffmpeg_required
def test_full_workflow(supa, pipeline_stubs, video_bytes, tmp_path):
    client = TestClient(main.app)
    alice = supa.add_user(ALICE)
    supa.add_user(BOB)

    # 1. Authentication
    assert client.get("/projects/x").status_code == 401
    assert client.post("/projects/x/process", headers=auth("forged")).status_code == 401
    health = client.get("/health").json()
    assert health["status"] == "ok" and health["ffmpeg"] is True

    # 2. Project creation and upload (the browser uploads to Storage, then inserts the row)
    pid, video_path = supa.create_project(alice, video_bytes, title="Interview")
    assert client.get(f"/projects/{pid}", headers=auth(ALICE)).json()["status"] == "uploaded"

    # Ownership: another user cannot see or start the project
    assert client.get(f"/projects/{pid}", headers=auth(BOB)).status_code == 404
    assert client.post(f"/projects/{pid}/process", headers=auth(BOB)).status_code == 404

    # 3. Processing: download, probe, extract audio, transcribe, find moments
    assert client.post(f"/projects/{pid}/process", headers=auth(ALICE)).status_code == 202
    assert client.post(f"/projects/{pid}/process", headers=auth(ALICE)).status_code == 409  # no double start
    status = wait_status(client, pid, auth(ALICE), {"ready", "failed"})
    assert status["status"] == "ready", status
    assert 59 <= float(supa.row("projects", pid)["duration_seconds"]) <= 61
    assert supa.has_object("audio", f"{alice}/{pid}.mp3")

    # 4. AI clip generation
    clips = client.get(f"/projects/{pid}/clips", headers=auth(ALICE)).json()
    assert len(clips) == 2 and {c["render_status"] for c in clips} == {"none"}
    words = client.get(f"/projects/{pid}/words?start=0&end=5", headers=auth(ALICE)).json()
    assert words and words[0]["word"].startswith("w0")

    # 5. FFmpeg rendering with a preview-style request (9:16, captions on)
    clip_id = clips[0]["id"]
    r = client.post(f"/projects/{pid}/render", headers=auth(ALICE),
                    json={"clip_ids": [clip_id], "aspect": "9:16", "captions": {"style": "karaoke"}})
    assert r.status_code == 202 and r.json() == {"queued": 1}
    done = wait_clip(client, pid, clip_id, auth(ALICE), {"done", "failed"})
    assert done["render_status"] == "done", done

    # 6. Export and download: the rendered file is in Storage, is the right size, and Alice can read it
    out_path = done["output_path"]
    assert out_path == f"{alice}/{pid}/{clip_id}.mp4"
    assert probe_size(supa.objects[("clips", out_path)], tmp_path) == "1080,1920"

    # 7. Error handling: a second project with a corrupt file fails with a readable message
    bad_pid, _ = supa.create_project(alice, b"definitely not a video", title="Broken upload")
    client.post(f"/projects/{bad_pid}/process", headers=auth(ALICE))
    bad = wait_status(client, bad_pid, auth(ALICE), {"failed", "ready"})
    assert bad["status"] == "failed" and "FFmpeg could not read this file" in bad["error_message"]
    # Rendering is refused until the analysis succeeds
    assert client.post(f"/projects/{bad_pid}/render", headers=auth(ALICE), json={}).status_code == 409

    # 8. Deletion: Bob cannot delete it; Alice can, and nothing is left behind
    assert client.delete(f"/projects/{pid}", headers=auth(BOB)).status_code == 404
    assert supa.has_object("videos", video_path)
    res = client.delete(f"/projects/{pid}", headers=auth(ALICE))
    assert res.status_code == 200 and res.json()["deleted"] is True
    assert supa.row("projects", pid) is None
    assert not supa.has_object("videos", video_path)
    assert not supa.has_object("audio", f"{alice}/{pid}.mp3")
    assert not supa.has_object("clips", out_path)
    assert supa.cleanup_queue() == []
    assert client.get(f"/projects/{pid}/clips", headers=auth(ALICE)).status_code == 404
    assert client.delete(f"/projects/{pid}", headers=auth(ALICE)).status_code == 404  # already gone
