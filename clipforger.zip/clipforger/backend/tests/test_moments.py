import json

import pytest

from app import moments
from app.errors import PipelineError


def fake_words(n_sentences=200, per=8, dt=0.4):
    words, t = [], 0.0
    for i in range(n_sentences):
        for j in range(per):
            end_mark = "." if j == per - 1 else ""
            words.append({"start": round(t, 2), "end": round(t + 0.35, 2), "word": f"w{i}_{j}{end_mark}"})
            t += dt
        t += 0.3
    return words


def test_sentences_split_on_punctuation():
    s = moments.build_sentences(fake_words(5))
    assert len(s) == 5 and s[0]["start"] == 0 and s[1]["start"] > s[0]["end"]


def test_selection_and_validation():
    words = fake_words(300)  # ~ 14 min
    sents = moments.build_sentences(words)
    first, last = sents[0]["start"], sents[-1]["end"]

    def llm(system, user):
        return "Here you go:\n" + json.dumps({"moments": [
            {"start_id": 10, "end_id": 20, "title": "Good", "category": "funny", "score": 92, "reason": "r"},
            {"start_id": 12, "end_id": 22, "title": "Overlaps better one", "category": "hook", "score": 70, "reason": "r"},
            {"start_id": 50, "end_id": 51, "title": "Too short", "category": "hook", "score": 99, "reason": "r"},
            {"start_id": 0, "end_id": 299, "title": "Too long", "category": "hook", "score": 99, "reason": "r"},
            {"start_id": 999, "end_id": 1000, "title": "Bad ids", "category": "hook", "score": 99, "reason": "r"},
            {"start_id": 100, "end_id": 110, "title": "Other", "category": "weird", "score": 80, "reason": "r"},
        ]})

    out = moments.find_moments(words, last - first, llm)
    assert [c["title"] for c in out] == ["Good", "Other"]
    assert out[1]["category"] == "insight"
    by_id = {s["id"]: s for s in sents}
    assert out[0]["start_seconds"] == pytest.approx(by_id[10]["start"] - 0.15, abs=0.01)  # snapped to sentence start


def test_unreadable_ai_answer_fails_cleanly():
    with pytest.raises(PipelineError):
        moments.find_moments(fake_words(50), 300, lambda s, u: "sorry, no JSON")


def test_long_video_uses_multiple_windows():
    sents = moments.build_sentences(fake_words(900))
    assert len(moments.windows(sents)) >= 2
