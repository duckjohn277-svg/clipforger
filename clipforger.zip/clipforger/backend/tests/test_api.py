import pytest
from fastapi.testclient import TestClient

from app import main
from app.auth import current_user_id

CID = "11111111-1111-1111-1111-111111111111"
calls = {}


@pytest.fixture()
def client(monkeypatch):
    main.app.dependency_overrides[current_user_id] = lambda: "u1"
    calls.clear()
    monkeypatch.setattr(main.db, "get_project", lambda pid: {"id": pid, "user_id": "u1", "status": "ready", "duration_seconds": 100})
    monkeypatch.setattr(main.db, "claim_clips", lambda pid, ids: [{"id": CID}])
    monkeypatch.setattr(main.db, "update_clip", lambda cid, **f: calls.update({"update": (cid, f)}))
    monkeypatch.setattr(main.db, "get_transcript_words", lambda pid: [{"start": 1, "end": 2, "word": "a", "prob": 1}, {"start": 50, "end": 51, "word": "b"}])
    monkeypatch.setattr(main.executor, "submit", lambda *a, **k: calls.update({"submit": a}))
    yield TestClient(main.app)
    main.app.dependency_overrides.clear()


def post(c, **body):
    return c.post("/projects/p1/render", json=body)


def test_trim_validation(client):
    assert post(client, clip_ids=[CID], start_seconds=10).status_code == 422          # end missing
    assert post(client, start_seconds=10, end_seconds=30).status_code == 422          # no single clip
    assert post(client, clip_ids=[CID], start_seconds=10, end_seconds=11).status_code == 422  # too short
    assert post(client, clip_ids=[CID], start_seconds=10, end_seconds=300).status_code == 422  # too long
    assert post(client, clip_ids=[CID], start_seconds=90, end_seconds=120).status_code == 422  # past end of video
    assert post(client, clip_ids=["../etc"], aspect="9:16").status_code == 422        # ids must be UUIDs
    assert post(client, aspect="4:3").status_code == 422
    assert "submit" not in calls


def test_trim_saved_then_queued(client):
    r = post(client, clip_ids=[CID], start_seconds=10, end_seconds=40, aspect="1:1", captions={"style": "pop", "font_size_pct": 7})
    assert r.status_code == 202
    assert calls["update"] == (CID, {"start_seconds": 10, "end_seconds": 40})
    opts = calls["submit"][3]
    assert opts["aspect"] == "1:1" and opts["captions"]["style"] == "pop"


def test_words_endpoint(client):
    assert [w["word"] for w in client.get("/projects/p1/words?start=0&end=10").json()] == ["a"]
    assert client.get("/projects/p1/words?start=0&end=5000").status_code == 422
