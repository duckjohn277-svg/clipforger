import hashlib
import json
import shutil
import subprocess

import pytest

from app import captions, render

ffmpeg = pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg not installed")
TEXT = "So the real secret to growing fast is actually consistency over 30 days not talent".split()
WORDS = [{"start": 3 + i * 0.4, "end": 3.35 + i * 0.4, "word": w} for i, w in enumerate(TEXT)]
OPTS = lambda **k: {"aspect": "9:16", "fit": "fill", "captions": {"enabled": True, "style": "karaoke", "font_size_pct": 9,
                    "position": "bottom", "offset_pct": 14, "highlight_keywords": True}, **k}


def test_ass_karaoke_timing_and_keywords():
    ass = captions.generate_ass(WORDS, 2.0, 9.0, 1080, 1920, OPTS()["captions"])
    assert "PlayResY: 1920" in ass and "Anton" in ass
    events = [l for l in ass.splitlines() if l.startswith("Dialogue")]
    assert len(events) == len(TEXT)               # one event per word
    assert events[0].split(",")[1] == "0:00:01.00"  # shifted by clip start
    assert captions.KEYWORD in ass and captions.ACCENT in ass
    assert "30" in "".join(events) and captions.keyword_index(["over", "30", "days"]) == 1


def test_styles_and_clipping_to_window():
    for style in captions.STYLES:
        o = {**OPTS()["captions"], "style": style}
        ass = captions.generate_ass(WORDS, 4.0, 6.0, 1080, 1080, o)
        assert ass.count("Dialogue") >= 1
        assert all(float(l.split(",")[1].split(":")[2]) <= 2.01 for l in ass.splitlines() if l.startswith("Dialogue"))
    assert captions.generate_ass([{"start": 3, "end": 4, "word": "{evil\\}"}], 0, 10, 1080, 1920, OPTS()["captions"]).count("EVIL") == 1


def _probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", path],
                         capture_output=True, text=True, check=True).stdout
    return json.loads(out)


def _frame(path, t):
    return hashlib.md5(subprocess.run(["ffmpeg", "-v", "error", "-ss", str(t), "-i", path, "-frames:v", "1",
                                       "-f", "rawvideo", "-pix_fmt", "gray", "-"], capture_output=True, check=True).stdout).hexdigest()


@ffmpeg
def test_render_sizes_and_burned_captions(tmp_path):
    src = tmp_path / "src.mp4"
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc=duration=12:size=1280x720:rate=25", "-f", "lavfi",
                    "-i", "sine=frequency=440:duration=12", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-shortest", str(src)],
                   check=True, capture_output=True)
    outs = {}
    for name, o in {"vert": OPTS(), "square_blur": OPTS(aspect="1:1", fit="blur"),
                    "land": OPTS(aspect="16:9"), "nocap": OPTS(captions={**OPTS()["captions"], "enabled": False})}.items():
        dst = tmp_path / f"{name}.mp4"
        render.render_clip(str(src), str(dst), 2.0, 8.0, WORDS, o, str(tmp_path))
        outs[name] = dst
    v = next(s for s in _probe(str(outs["vert"]))["streams"] if s["codec_type"] == "video")
    assert (v["width"], v["height"]) == (1080, 1920)
    assert 5.5 < float(_probe(str(outs["vert"]))["format"]["duration"]) < 6.5
    assert any(s["codec_type"] == "audio" for s in _probe(str(outs["vert"]))["streams"])
    sq = next(s for s in _probe(str(outs["square_blur"]))["streams"] if s["codec_type"] == "video")
    assert (sq["width"], sq["height"]) == (1080, 1080)
    ld = next(s for s in _probe(str(outs["land"]))["streams"] if s["codec_type"] == "video")
    assert (ld["width"], ld["height"]) == (1920, 1080)
    assert _frame(str(outs["vert"]), 3.0) != _frame(str(outs["nocap"]), 3.0)  # captions are actually drawn
