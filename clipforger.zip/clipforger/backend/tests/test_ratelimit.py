"""Rate limiting: parsing, per-user limits, 429 responses, Redis sharing, and the outage fallback."""
import fakeredis
import pytest
import redis
from fastapi.testclient import TestClient

from app import main, ratelimit
from app.config import settings


def test_parse_accepts_count_and_unit():
    assert ratelimit.parse("10/hour") == (10, 3600)
    assert ratelimit.parse("600/minute") == (600, 60)
    assert ratelimit.parse(" 5 / seconds ") == (5, 1)
    with pytest.raises(ValueError):
        ratelimit.parse("ten per hour")


def test_process_endpoint_returns_429_with_retry_after(supa, monkeypatch):
    monkeypatch.setattr(settings, "rl_process", "2/hour")
    client = TestClient(main.app)
    supa.add_user("rl-alice")
    h = {"Authorization": "Bearer rl-alice"}
    assert client.post("/projects/nope/process", headers=h).status_code == 404  # 1st: allowed through
    assert client.post("/projects/nope/process", headers=h).status_code == 404  # 2nd: allowed
    r = client.post("/projects/nope/process", headers=h)                       # 3rd: over the limit
    assert r.status_code == 429
    assert int(r.headers["Retry-After"]) > 0 and r.headers["RateLimit-Remaining"] == "0"
    assert "Too many requests" in r.json()["detail"]


def test_limits_are_per_user_not_global(supa, monkeypatch):
    monkeypatch.setattr(settings, "rl_process", "1/hour")
    client = TestClient(main.app)
    supa.add_user("rl-carol")
    supa.add_user("rl-dave")
    assert client.post("/projects/nope/process", headers={"Authorization": "Bearer rl-carol"}).status_code == 404
    assert client.post("/projects/nope/process", headers={"Authorization": "Bearer rl-carol"}).status_code == 429
    assert client.post("/projects/nope/process", headers={"Authorization": "Bearer rl-dave"}).status_code == 404


def test_read_limit_covers_status_polling(supa, monkeypatch):
    monkeypatch.setattr(settings, "rl_read", "2/minute")
    client = TestClient(main.app)
    supa.add_user("rl-erin")
    h = {"Authorization": "Bearer rl-erin"}
    assert client.get("/projects/nope", headers=h).status_code == 404
    assert client.get("/projects/nope", headers=h).status_code == 404
    assert client.get("/projects/nope", headers=h).status_code == 429


def test_unauthenticated_requests_are_rejected_before_counting(supa, monkeypatch):
    monkeypatch.setattr(settings, "rl_process", "1/hour")
    client = TestClient(main.app)
    for _ in range(3):
        assert client.post("/projects/nope/process").status_code == 401  # never reaches the limiter


def test_disabled_flag_turns_limits_off(supa, monkeypatch):
    monkeypatch.setattr(settings, "rl_process", "1/hour")
    monkeypatch.setattr(settings, "rate_limits_enabled", False)
    client = TestClient(main.app)
    supa.add_user("rl-frank")
    for _ in range(3):
        assert client.post("/projects/nope/process", headers={"Authorization": "Bearer rl-frank"}).status_code == 404


def test_redis_counts_are_shared_between_instances():
    server = fakeredis.FakeServer()
    instance_a = ratelimit.RedisStore(fakeredis.FakeRedis(server=server))
    instance_b = ratelimit.RedisStore(fakeredis.FakeRedis(server=server))
    assert instance_a.hit("process:u1", 3600)[0] == 1
    assert instance_a.hit("process:u1", 3600)[0] == 2
    count, retry = instance_b.hit("process:u1", 3600)  # a second instance sees the first one's hits
    assert count == 3 and 0 < retry <= 3600


def test_redis_outage_falls_back_to_in_process_counting(monkeypatch):
    class Down:
        def incr(self, *a, **k):
            raise redis.ConnectionError("down")

    monkeypatch.setattr(ratelimit, "_client", Down())
    counts = [ratelimit.hit("process:u2", 3600)[0] for _ in range(3)]
    assert counts == [1, 2, 3]  # still limited, not failed open
