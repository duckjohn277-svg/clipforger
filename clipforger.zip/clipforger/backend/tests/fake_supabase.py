"""A small in-process stand-in for the Supabase endpoints the backend uses: PostgREST (tables),
Storage (objects) and Auth (token -> user). It speaks real HTTP, so the backend's httpx code runs
unchanged. It also reproduces the migration-007 triggers, so tests see the same cleanup queue
that Postgres would produce.

It is not a database. It implements only the filter syntax Clipforger uses:
eq, in, not.in, lt, is.null, and top-level 'or'."""
import json
import threading
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, unquote, urlparse

RESERVED = {"select", "order", "limit", "on_conflict"}


def _ts(v) -> datetime:
    if isinstance(v, datetime):
        return v
    dt = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _cond(row: dict, col: str, expr: str) -> bool:
    neg = expr.startswith("not.")
    if neg:
        expr = expr[4:]
    op, _, val = expr.partition(".")
    actual = row.get(col)
    if op == "eq":
        ok = actual is not None and str(actual) == val
    elif op == "in":
        ok = actual is not None and str(actual) in val.strip("()").split(",")
    elif op == "is":
        ok = actual is None if val == "null" else False
    elif op == "lt":
        ok = actual is not None and _ts(actual) < _ts(val)
    else:
        raise ValueError(f"unsupported filter op {op!r}")
    return ok != neg


def _pass(row: dict, key: str, value: str) -> bool:
    if key == "or":
        return any(_pass(row, *part.split(".", 1)) for part in value.strip("()").split(","))
    return _cond(row, key, value)


class FakeSupabase:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.tables: dict[str, dict] = {"projects": {}, "clips": {}, "transcripts": {}, "storage_cleanup": {}}
        self.objects: dict[tuple[str, str], bytes] = {}
        self.users: dict[str, str] = {}  # access token -> user id
        self._seq = 0
        self._server = None

    # ---- lifecycle ----------------------------------------------------------------------
    def start(self) -> str:
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self._server.fake = self
        threading.Thread(target=self._server.serve_forever, daemon=True).start()
        return f"http://127.0.0.1:{self._server.server_address[1]}"

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server.server_close()

    # ---- test helpers (act like the browser or the database would) -----------------------
    def add_user(self, token: str, user_id: str | None = None) -> str:
        uid = user_id or str(uuid.uuid4())
        self.users[token] = uid
        return uid

    def create_project(self, user_id: str, video: bytes, title: str = "Test video", size_bytes: int | None = None) -> tuple[str, str]:
        """Mirror the browser flow: upload to 'videos' under {uid}/{uuid}.mp4, then insert the project row."""
        pid = str(uuid.uuid4())
        path = f"{user_id}/{uuid.uuid4()}.mp4"
        with self.lock:
            self.objects[("videos", path)] = video
            self.tables["projects"][pid] = {
                "id": pid, "user_id": user_id, "title": title, "status": "uploaded", "storage_path": path,
                "size_bytes": size_bytes or len(video), "duration_seconds": None, "processing_step": None,
                "error_message": None, "audio_path": None, "locked_until": None, "created_at": self._now(),
            }
        return pid, path

    def row(self, table: str, key: str) -> dict | None:
        with self.lock:
            return dict(self.tables[table][key]) if key in self.tables[table] else None

    def set_row(self, table: str, key: str, **fields) -> None:
        with self.lock:
            self.tables[table][key].update(fields)

    def put_object(self, bucket: str, path: str, data: bytes = b"x") -> None:
        with self.lock:
            self.objects[(bucket, path)] = data

    def has_object(self, bucket: str, path: str) -> bool:
        with self.lock:
            return (bucket, path) in self.objects

    def objects_for(self, prefix: str) -> list[tuple[str, str]]:
        with self.lock:
            return sorted(k for k in self.objects if k[1].startswith(prefix))

    def cleanup_queue(self) -> list[dict]:
        with self.lock:
            return [dict(r) for r in self.tables["storage_cleanup"].values()]

    # ---- PostgREST -----------------------------------------------------------------------
    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _next(self) -> int:
        self._seq += 1
        return self._seq

    def _pk(self, table: str) -> str:
        return {"transcripts": "project_id"}.get(table, "id")

    def _filter(self, table: str, params: list) -> list[dict]:
        filters = [(k, v) for k, v in params if k not in RESERVED]
        rows = [r for r in self.tables[table].values() if all(_pass(r, k, v) for k, v in filters)]
        order = dict(params).get("order")
        if order:
            for part in reversed(order.split(",")):
                col, _, direction = part.partition(".")
                rows.sort(key=lambda r: (r.get(col) is None, r.get(col)), reverse=(direction == "desc"))
        limit = dict(params).get("limit")
        return rows[: int(limit)] if limit else rows

    def _delete(self, table: str, rows: list[dict]) -> None:
        for r in rows:
            self.tables[table].pop(r[self._pk(table)], None)
        if table == "projects":
            for r in rows:
                # Cascades (clips, transcripts) and the migration-007 trigger on projects.
                self._enqueue("audio", f"{r['user_id']}/{r['id']}.mp3", r["id"], r["user_id"])
                if r.get("storage_path"):
                    self._enqueue("videos", r["storage_path"], r["id"], r["user_id"])
                if r.get("audio_path"):
                    self._enqueue("audio", r["audio_path"], r["id"], r["user_id"])
                clips = [c for c in self.tables["clips"].values() if c["project_id"] == r["id"]]
                self._delete("clips", clips)
                for k in [k for k, t in self.tables["transcripts"].items() if t["project_id"] == r["id"]]:
                    del self.tables["transcripts"][k]
        if table == "clips":
            for r in rows:  # migration-007 trigger on clips
                self._enqueue("clips", f"{r['user_id']}/{r['project_id']}/{r['id']}.mp4", r["project_id"], r["user_id"])
                if r.get("output_path"):
                    self._enqueue("clips", r["output_path"], r["project_id"], r["user_id"])

    def _enqueue(self, bucket: str, path: str, project_id: str, user_id: str) -> None:
        if any(r["bucket"] == bucket and r["path"] == path for r in self.tables["storage_cleanup"].values()):
            return
        i = self._next()
        self.tables["storage_cleanup"][i] = {"id": i, "bucket": bucket, "path": path, "project_id": project_id,
                                             "user_id": user_id, "attempts": 0, "last_error": None, "created_at": self._now()}

    def rest(self, method: str, table: str, params: list, body: bytes, headers) -> tuple[int, object]:
        prefer = headers.get("Prefer", "") or ""
        payload = json.loads(body) if body else None
        with self.lock:
            if table not in self.tables:
                return 404, {"message": f"no table {table}"}
            if method == "GET":
                rows = self._filter(table, params)
                return 200, [dict(r) for r in rows]
            if method == "PATCH":
                rows = self._filter(table, params)
                for r in rows:
                    r.update(payload)
                return (200, [dict(r) for r in rows]) if "representation" in prefer else (204, None)
            if method == "DELETE":
                rows = self._filter(table, params)
                self._delete(table, rows)
                return (200, [dict(r) for r in rows]) if "representation" in prefer else (204, None)
            if method == "POST":
                incoming = payload if isinstance(payload, list) else [payload]
                conflict = (dict(params).get("on_conflict") or self._pk(table)).split(",")
                out = []
                for r in incoming:
                    r = dict(r)
                    existing = next((x for x in self.tables[table].values()
                                     if all(str(x.get(c)) == str(r.get(c)) for c in conflict)), None)
                    if existing is not None:
                        if "ignore-duplicates" in prefer:
                            continue
                        if "merge-duplicates" in prefer:
                            existing.update(r)
                            out.append(dict(existing))
                            continue
                        return 409, {"message": "duplicate key"}
                    if table == "storage_cleanup":
                        r.setdefault("id", self._next())
                        r.setdefault("attempts", 0)
                        r.setdefault("created_at", self._now())
                    elif self._pk(table) == "id":
                        r.setdefault("id", str(uuid.uuid4()))
                    if table == "clips":  # column defaults from migrations 004-005
                        r.setdefault("render_status", "none")
                        r.setdefault("created_at", self._now())
                    self.tables[table][r[self._pk(table)]] = r
                    out.append(dict(r))
                return (201, out) if "representation" in prefer else (201, None)
        return 405, {"message": method}

    # ---- Storage -------------------------------------------------------------------------
    def storage_delete(self, bucket: str, prefixes: list[str]) -> tuple[int, object]:
        with self.lock:
            for p in prefixes:
                self.objects.pop((bucket, p), None)
        return 200, [{"name": p} for p in prefixes]


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args) -> None:  # keep test output quiet
        pass

    def _send(self, status: int, payload=None, raw: bytes | None = None) -> None:
        body = raw if raw is not None else (b"" if payload is None else json.dumps(payload).encode())
        self.send_response(status)
        self.send_header("Content-Type", "application/octet-stream" if raw is not None else "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _route(self, method: str) -> None:
        f: FakeSupabase = self.server.fake
        url = urlparse(self.path)
        params = parse_qsl(url.query, keep_blank_values=True)
        n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else b""

        if url.path == "/auth/v1/user":
            token = (self.headers.get("Authorization") or "").replace("Bearer ", "", 1).strip()
            uid = f.users.get(token)
            return self._send(200, {"id": uid}) if uid else self._send(401, {"message": "invalid JWT"})
        if url.path.startswith("/rest/v1/"):
            status, payload = f.rest(method, url.path[len("/rest/v1/"):], params, body, self.headers)
            return self._send(status, payload)
        if url.path.startswith("/storage/v1/object/"):
            rest = unquote(url.path[len("/storage/v1/object/"):])
            if method == "DELETE" and "/" not in rest:
                status, payload = f.storage_delete(rest, json.loads(body)["prefixes"])
                return self._send(status, payload)
            bucket, _, path = rest.partition("/")
            with f.lock:
                if method == "POST":
                    f.objects[(bucket, path)] = body
                    return self._send(200, {"Key": f"{bucket}/{path}"})
                if method == "GET":
                    data = f.objects.get((bucket, path))
                    return self._send(200, raw=data) if data is not None else self._send(404, {"message": "not found"})
        self._send(404, {"message": "not found"})

    def do_GET(self) -> None:
        self._route("GET")

    def do_POST(self) -> None:
        self._route("POST")

    def do_PATCH(self) -> None:
        self._route("PATCH")

    def do_DELETE(self) -> None:
        self._route("DELETE")
