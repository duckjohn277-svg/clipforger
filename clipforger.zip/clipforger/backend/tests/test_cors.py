"""CORS: only the configured web origins may call the API from a browser."""
import pytest
from fastapi.testclient import TestClient

from app.config import settings

PROD = "https://app.example.com"


def preflight(client, origin: str):
    return client.options("/projects/x/process", headers={
        "Origin": origin, "Access-Control-Request-Method": "POST",
        "Access-Control-Request-Headers": "authorization,content-type"})


@pytest.fixture()
def cors(monkeypatch):
    monkeypatch.setattr(settings, "frontend_origins", [PROD, "https://www.example.com"])
    monkeypatch.setattr(settings, "frontend_origin_regex", None)
    # The middleware is built at import time, so rebuild the app with the test settings.
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    app = FastAPI()
    app.add_middleware(CORSMiddleware, allow_origins=settings.frontend_origins,
                       allow_origin_regex=settings.frontend_origin_regex,
                       allow_methods=["GET", "POST", "DELETE"], allow_headers=["Authorization", "Content-Type"])

    @app.post("/projects/{pid}/process")
    def _p(pid: str):
        return {}

    return TestClient(app)


def test_configured_origin_is_allowed(cors):
    r = preflight(cors, PROD)
    assert r.headers.get("access-control-allow-origin") == PROD


def test_second_configured_origin_is_allowed(cors):
    assert preflight(cors, "https://www.example.com").headers.get("access-control-allow-origin") == "https://www.example.com"


def test_unlisted_origin_is_refused(cors):
    assert "access-control-allow-origin" not in preflight(cors, "https://evil.example.net").headers


def test_preview_regex_allows_matching_origins_only(cors, monkeypatch):
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    pattern = r"^https://clipforger-[a-z0-9-]+\.vercel\.app$"
    app = FastAPI()
    app.add_middleware(CORSMiddleware, allow_origins=[PROD], allow_origin_regex=pattern,
                       allow_methods=["POST"], allow_headers=["Authorization", "Content-Type"])

    @app.post("/x")
    def _x():
        return {}

    client = TestClient(app)
    ok = client.options("/x", headers={"Origin": "https://clipforger-git-feat-team.vercel.app",
                                       "Access-Control-Request-Method": "POST"})
    bad = client.options("/x", headers={"Origin": "https://clipforger.vercel.app.evil.net",
                                        "Access-Control-Request-Method": "POST"})
    assert ok.headers.get("access-control-allow-origin") == "https://clipforger-git-feat-team.vercel.app"
    assert "access-control-allow-origin" not in bad.headers


def test_settings_parse_comma_separated_origins(monkeypatch):
    import importlib
    import app.config as cfg
    monkeypatch.setenv("FRONTEND_ORIGIN", "https://a.example.com/, https://b.example.com ,")
    reloaded = importlib.reload(cfg)
    assert reloaded.Settings.frontend_origins == ["https://a.example.com", "https://b.example.com"]
    monkeypatch.delenv("FRONTEND_ORIGIN")
    importlib.reload(cfg)  # restore defaults for the rest of the suite
