"""Failed-job recovery: dead workers, expired leases, retries, and failed renders."""
import time

from fastapi.testclient import TestClient

from app import db, main, recovery, render
from app.errors import PipelineError
from app.config import settings
from conftest import ffmpeg_required
from helpers import wait_clip, wait_status

TOKEN = "recovery-token"


def auth() -> dict:
    return {"Authorization": f"Bearer {TOKEN}"}


def test_live_lease_is_not_reaped(supa):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"x")
    supa.set_row("projects", pid, status="processing", locked_until="2999-01-01T00:00:00Z")
    recovery.reap()
    assert supa.row("projects", pid)["status"] == "processing"


def test_expired_lease_is_recovered_and_retry_is_allowed(supa, pipeline_stubs, video_bytes):
    client = TestClient(main.app)
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, video_bytes)
    # The worker died mid-job: status says processing, and its lease ran out long ago.
    supa.set_row("projects", pid, status="processing", processing_step="transcribing", locked_until="2000-01-01T00:00:00Z")
    recovery.reap()
    row = supa.row("projects", pid)
    assert row["status"] == "failed" and row["error_message"] == recovery.STALE_PROJECT
    # Retry succeeds (this is the recovery path a user actually takes).
    assert client.post(f"/projects/{pid}/process", headers=auth()).status_code == 202
    assert wait_status(client, pid, auth(), {"ready", "failed"})["status"] == "ready"


def test_legacy_processing_row_without_lease_is_recovered(supa):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"x")
    supa.set_row("projects", pid, status="processing", locked_until=None)
    assert recovery.reap()["projects"] == 1
    assert supa.row("projects", pid)["status"] == "failed"


def test_heartbeat_moves_an_expired_lease_into_the_future(supa, monkeypatch):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"x")
    supa.set_row("projects", pid, locked_until="2000-01-01T00:00:00Z")  # lease long expired
    monkeypatch.setattr(settings, "heartbeat_seconds", 0.05)
    with recovery.heartbeat("projects", [pid]):
        time.sleep(0.2)
        assert supa.row("projects", pid)["locked_until"] > db.utc_iso()  # renewed while the job runs
    recovery.reap()  # the live job is not reaped
    assert supa.row("projects", pid)["status"] != "failed"


def test_stale_render_is_recovered(supa):
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, b"x")
    supa.set_row("projects", pid, status="ready")
    cid = "11111111-1111-1111-1111-111111111111"
    supa.tables["clips"][cid] = {"id": cid, "project_id": pid, "user_id": uid, "start_seconds": 0, "end_seconds": 25,
                                 "render_status": "rendering", "locked_until": "2000-01-01T00:00:00Z"}
    recovery.reap()
    clip = supa.row("clips", cid)
    assert clip["render_status"] == "failed" and clip["render_error"] == recovery.STALE_CLIP


@ffmpeg_required
def test_failed_render_keeps_project_ready_and_can_be_retried(supa, pipeline_stubs, video_bytes, monkeypatch):
    client = TestClient(main.app)
    uid = supa.add_user(TOKEN)
    pid, _ = supa.create_project(uid, video_bytes)
    client.post(f"/projects/{pid}/process", headers=auth())
    assert wait_status(client, pid, auth(), {"ready", "failed"})["status"] == "ready"
    clip_id = client.get(f"/projects/{pid}/clips", headers=auth()).json()[0]["id"]

    real = render.render_clip

    def broken(*args, **kwargs):
        raise PipelineError("FFmpeg could not render this clip.")

    monkeypatch.setattr(render, "render_clip", broken)
    client.post(f"/projects/{pid}/render", headers=auth(), json={"clip_ids": [clip_id]})
    failed = wait_clip(client, pid, clip_id, auth(), {"failed", "done"})
    assert failed["render_status"] == "failed" and failed["render_error"] == "FFmpeg could not render this clip."
    assert wait_status(client, pid, auth(), {"ready"})["status"] == "ready"  # the project itself is unharmed

    monkeypatch.setattr(render, "render_clip", real)
    assert client.post(f"/projects/{pid}/render", headers=auth(), json={"clip_ids": [clip_id]}).status_code == 202
    assert wait_clip(client, pid, clip_id, auth(), {"done", "failed"})["render_status"] == "done"
