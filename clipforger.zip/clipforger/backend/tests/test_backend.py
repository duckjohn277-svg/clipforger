import shutil
import subprocess

import pytest
from fastapi.testclient import TestClient

from app import media
from app.main import app

ffmpeg = pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg not installed")


def make_video(path, audio=True):
    cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc=duration=3:size=320x240:rate=15"]
    if audio:
        cmd += ["-f", "lavfi", "-i", "sine=frequency=440:duration=3"]
    subprocess.run(cmd + ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-shortest", str(path)], check=True, capture_output=True)


def test_requires_auth():
    c = TestClient(app)
    assert c.post("/projects/x/process").status_code == 401
    assert c.get("/projects/x").status_code == 401


def test_health():
    assert TestClient(app).get("/health").json()["status"] == "ok"


@ffmpeg
def test_probe_and_extract(tmp_path):
    v, a = tmp_path / "v.mp4", tmp_path / "a.mp3"
    make_video(v)
    assert 2.5 < media.probe(str(v))["duration"] < 3.5
    media.extract_audio(str(v), str(a), 3)
    assert a.stat().st_size > 1000


@ffmpeg
def test_no_audio_and_garbage(tmp_path):
    v = tmp_path / "silent.mp4"
    make_video(v, audio=False)
    with pytest.raises(media.MediaError, match="no audio"):
        media.probe(str(v))
    bad = tmp_path / "bad.mp4"
    bad.write_bytes(b"not a video")
    with pytest.raises(media.MediaError):
        media.probe(str(bad))
