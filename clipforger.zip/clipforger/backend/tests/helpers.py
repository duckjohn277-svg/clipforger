"""Shared test helpers. Imported by conftest and test modules (tests/ is on sys.path)."""
import json
import subprocess
import time

from app import moments

WORD_SECONDS = 0.5
WORDS = 120  # 60 s of speech


def make_words() -> list[dict]:
    out = []
    for i in range(WORDS):
        text = f"w{i}." if (i + 1) % 10 == 0 else f"w{i}"
        out.append({"start": round(i * WORD_SECONDS, 2), "end": round((i + 1) * WORD_SECONDS, 2),
                    "word": text, "prob": 0.99})
    return out


def fake_transcribe(audio_path: str) -> dict:
    words = make_words()
    segments = [{"start": 0.0, "end": float(WORDS * WORD_SECONDS), "text": " ".join(w["word"] for w in words)}]
    return {"language": "en", "segments": segments, "words": words}


def fake_llm(system: str, user: str) -> str:
    """Pick two non-overlapping moments of five sentences each (about 25 s, inside the 20-90 s range)."""
    sents = moments.build_sentences(make_words())
    picks = [(0, 4, "Opening hook", "hook", 92), (6, 10, "Key insight", "insight", 85)]
    return json.dumps({"moments": [
        {"start_id": sents[a]["id"], "end_id": sents[b]["id"], "title": t, "category": c,
         "score": s, "reason": "Strong self-contained point."} for a, b, t, c, s in picks]})


def wait_until(predicate, timeout: float = 240, interval: float = 0.25):
    deadline = time.time() + timeout
    while time.time() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(interval)
    raise AssertionError("timed out waiting for condition")


def wait_status(client, pid: str, headers: dict, done: set[str]) -> dict:
    return wait_until(lambda: (lambda s: s if s["status"] in done else None)(
        client.get(f"/projects/{pid}", headers=headers).json()))


def wait_clip(client, pid: str, clip_id: str, headers: dict, done: set[str]) -> dict:
    def check():
        for c in client.get(f"/projects/{pid}/clips", headers=headers).json():
            if c["id"] == clip_id and c["render_status"] in done:
                return c
        return None
    return wait_until(check)


def probe_size(data: bytes, directory) -> str:
    path = directory / "probe.mp4"
    path.write_bytes(data)
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True, check=True).stdout.strip()
    return out  # "w,h"
