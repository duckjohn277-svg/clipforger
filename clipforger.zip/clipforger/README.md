# Clipforger AI

Upload long videos, get captioned short-form clips.

## Status
- Stage 1 (landing page, responsive layout): done
- Stage 2 (Supabase auth, protected dashboard): code written; needs your Supabase project to test end to end
- Stage 3 (upload to Supabase Storage, preview, project page): code written; needs your Supabase project to test
- Stage 4 (backend pipeline: FFmpeg audio extraction, background jobs): backend tests pass; end-to-end run needs your Supabase project
- Stage 5 (Whisper transcription, AI moment detection): detection logic tested with a fake LLM; transcription and live LLM calls untested
- Stage 6 (FFmpeg clip rendering, 9:16/1:1/16:9, animated captions): backend tested with real FFmpeg; the full browser flow needs your Supabase project
- Stage 7 (clip editor: trim, aspect ratio, caption styling, live preview, export): backend and caption logic tested; the editor UI builds but has not been run in a browser
- Stage 8 (end-to-end testing, rate limiting, project deletion, job recovery, Docker, deployment): done. The API workflow tests pass against real FFmpeg and a fake Supabase; a real browser run and a real Supabase project still need checking (see DEPLOYMENT.md section 9).

## Supabase setup (Stage 2)
1. Create a project at supabase.com.
2. SQL editor: run `supabase/migrations/001_profiles_projects_clips.sql`.
2b. Also run `supabase/migrations/002_video_storage.sql` (creates the private `videos` bucket; Supabase free plan caps files at 50 MB, so lower `file_size_limit` and `NEXT_PUBLIC_MAX_UPLOAD_MB` to match).
2c. Also run `supabase/migrations/003_processing.sql` `004_transcripts_moments.sql` and `005_rendering.sql` and `006_clip_range_check.sql`.
3. Project Settings > API: copy the URL and anon key into `frontend/.env.local`.
4. Authentication > URL Configuration: add `http://localhost:3000/auth/callback` to Redirect URLs.
5. Google sign-in: Authentication > Providers > Google, with a client ID and secret from Google Cloud Console. Add the callback URL Supabase shows to Google's authorized redirect URIs.
6. Email sign-up sends a confirmation email by default. Turn that off in Authentication > Providers > Email while testing if you prefer.

## Run the frontend
    cd frontend
    cp .env.example .env.local
    npm install
    npm run dev          # http://localhost:3000

## Run the backend
Install FFmpeg first (`brew install ffmpeg` or `sudo apt install ffmpeg`).

    cd backend
    cp .env.example .env      # add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements-dev.txt
    pytest                    # media tests need ffmpeg
    uvicorn app.main:app --reload   # http://localhost:8000/health (reports whether ffmpeg is found)

## Layout
- `frontend/` Next.js 16, React 19, TypeScript, Tailwind, Framer Motion
- `backend/` FastAPI (FFmpeg and Whisper arrive in Stages 4-5)
- `supabase/` SQL migrations 001 to 007
- `backend/Dockerfile` production image (FFmpeg bundled, health check, non-root)

Secrets live only in `.env` files, which are git-ignored. Never put the service-role key in the frontend.

## AI setup (Stage 5)
- Transcription: `faster-whisper` runs locally. The first run downloads the model (`WHISPER_MODEL=small` is about 500 MB); use `base` for speed or `medium` for accuracy. Set `WHISPER_DEVICE=cuda` and `WHISPER_COMPUTE_TYPE=float16` on a GPU.
- Moment detection: set `ANTHROPIC_API_KEY` in `backend/.env`. `LLM_MODEL` defaults to `claude-sonnet-5-5`.
- The model picks whole sentences by id; start and end times come from the transcript, so clips begin and end on sentence boundaries.

## Rendering (Stage 6)
Captions are generated as ASS subtitles from Whisper's word timestamps and burned in by FFmpeg (needs libass, included in standard builds). Four presets: karaoke, bold, pop, minimal. Keywords (numbers, then the longest non-filler word per caption) are highlighted. The caption font is Anton (SIL OFL licence, in `backend/fonts/`). Reframing is a center crop (`fill`) or full frame over a blurred background (`blur`); there is no face tracking yet. Rendering all clips of a project downloads the source video once.

## Editor (Stage 7)
`/dashboard/projects/[id]/clips/[clipId]`. The preview plays the source video inside a frame of the chosen aspect ratio with an HTML caption overlay. `frontend/lib/captions.ts` mirrors `backend/app/captions.py` (word grouping and keyword choice are checked to match), but fonts and blur are approximations; the exported MP4 is the source of truth. Exporting saves the trim to the clip, then renders with the chosen options. Trims can extend up to 60 s beyond the suggested range.

## Processing model
Jobs run in a thread pool inside the API process (`PROCESSING_WORKERS`). Job state lives in the database. Each running job renews a lease; a job whose lease expires (its worker died) is marked failed so the user can retry. This works across several backend instances. Rate limits use Redis when `REDIS_URL` is set. See DEPLOYMENT.md.

## Deletion (Stage 8)
`DELETE /projects/{id}` removes the project, its clips and transcript, and every stored file. Database triggers queue the files, so no deletion path can leave orphans. Run the tests with `cd backend && pytest`.

## Deployment
The web app deploys to Vercel with Root Directory `frontend` (see DEPLOYMENT.md section 6a). The API and its FFmpeg and Whisper workers run on a container host (section 6); Vercel cannot run them.

See `DEPLOYMENT.md` for local setup, Docker, Supabase migrations (001 to 007), Redis, environment variables and troubleshooting.
