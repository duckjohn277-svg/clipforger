# Clipforger AI: Deployment Guide

Clipforger has three parts:

- **Frontend**: Next.js 16 with React 19 (`frontend/`). Static pages plus server-rendered dashboard pages. Deploy to any Node host (Vercel, Netlify, a container, or `next start`).
- **Backend**: FastAPI (`backend/`) with FFmpeg and faster-whisper. Runs as one container (`backend/Dockerfile`). Long-running jobs run in its thread pool.
- **Supabase**: Postgres, Auth (email and Google), and Storage (the `videos`, `audio` and `clips` buckets).

Redis is optional. Set it when you run more than one backend instance, so rate limits are shared between them.

Secrets belong only in environment files or your host's secret store. The Supabase **service-role key** and the Anthropic key must never reach the frontend or the browser. The frontend uses only `NEXT_PUBLIC_*` values, which are public by design.

---

## 1. Local development

### Prerequisites
- Node.js 20.9 or newer (Next.js 16 requires it)
- Python 3.12
- FFmpeg with libass (`brew install ffmpeg`, or `sudo apt install ffmpeg`). Check with `ffmpeg -filters | grep ass`.
- A Supabase project (free tier is fine for testing)

### Supabase project
Complete section 3 first, so the database and buckets exist.

### Frontend
```bash
cd frontend
cp .env.example .env.local        # fill in NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm ci
npm run dev                       # http://localhost:3000
```

### Backend
```bash
cd backend
cp .env.example .env              # fill in SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (and ANTHROPIC_API_KEY for AI moments)
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload     # http://localhost:8000/health
```

The first transcription downloads the Whisper model (`small` is about 500 MB). Use `WHISPER_MODEL=base` for a faster first run.

### Run the tests
```bash
cd backend
pytest -q                         # about 70 seconds; needs ffmpeg
```
The suite runs the full workflow through the real HTTP API against an in-process fake of Supabase. It uses real FFmpeg for audio extraction, rendering and output checks. Only the two AI calls (transcription and the LLM) are stubbed. See section 9 for what is and isn't covered.

---

## 2. Environment variables

### Backend (`backend/.env`, or the container's environment)

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `SUPABASE_URL` | yes | | Project URL, `https://<ref>.supabase.co` |
| `SUPABASE_SERVICE_ROLE_KEY` | yes | | Backend only. Bypasses row-level security. |
| `FRONTEND_ORIGIN` | yes in prod | `http://localhost:3000` | Comma-separated origins allowed by CORS, e.g. `https://app.example.com,https://www.example.com` |
| `FRONTEND_ORIGIN_REGEX` | no | empty | Regex for per-deployment origins, such as Vercel previews (see 6a) |
| `PROCESSING_WORKERS` | no | `2` | Concurrent jobs per instance |
| `MAX_UPLOAD_MB` | no | `500` | Refuses larger source files |
| `MAX_VIDEO_MINUTES` | no | `240` | Refuses longer videos |
| `ANTHROPIC_API_KEY` | for AI moments | | Moment detection |
| `LLM_MODEL` | no | `claude-sonnet-5-5` | Model for moment detection |
| `WHISPER_MODEL` | no | `small` | `tiny`, `base`, `small`, `medium` |
| `WHISPER_DEVICE` | no | `auto` | `cpu`, `cuda` or `auto` |
| `WHISPER_COMPUTE_TYPE` | no | `int8` | `float16` on GPU |
| `CLIP_MIN_SECONDS` / `CLIP_MAX_SECONDS` | no | `20` / `90` | Clip length range |
| `REDIS_URL` | no | empty | `redis://` or `rediss://` URL. Shares rate limits across instances. Empty means in-process limits. |
| `RATE_LIMITS_ENABLED` | no | `true` | Set `false` only for debugging |
| `RATE_LIMIT_PROCESS` | no | `10/hour` | Starting analysis, per user |
| `RATE_LIMIT_RENDER` | no | `60/hour` | Rendering clips, per user |
| `RATE_LIMIT_DELETE` | no | `30/hour` | Deleting projects, per user |
| `RATE_LIMIT_READ` | no | `600/minute` | Status polling and listings, per user |
| `JOB_LEASE_SECONDS` | no | `600` | How long a dead worker's lock lasts before recovery |
| `QUEUE_GRACE_SECONDS` | no | `1800` | How long a job may wait in the pool before it starts |
| `HEARTBEAT_SECONDS` | no | `60` | How often running jobs renew their lock |
| `MAINTENANCE_SECONDS` | no | `60` | How often stale jobs are recovered and the cleanup queue runs |

Rate-limit values use the form `count/unit`, where unit is `second`, `minute`, `hour` or `day`.

### Frontend (`frontend/.env.local` in dev, or your host's settings)

| Variable | Required | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | yes | Same Supabase URL as the backend |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | yes | The **anon** key, which is public by design. Never put the service-role key here. |
| `NEXT_PUBLIC_API_URL` | yes | Public URL of the backend, e.g. `https://api.example.com` |
| `NEXT_PUBLIC_MAX_UPLOAD_MB` | no | Must match what your Supabase plan allows |

---

## 3. Supabase configuration

### 3.1 Run the migrations, in order
In the Supabase dashboard, open **SQL Editor** and run each file in `supabase/migrations/`, in this order:

1. `001_profiles_projects_clips.sql`: tables, row-level security, profile trigger
2. `002_video_storage.sql`: `videos` bucket and its policies
3. `003_processing.sql`: processing columns, `audio` bucket
4. `004_transcripts_moments.sql`: transcripts table, clip analysis columns
5. `005_rendering.sql`: rendering columns, `clips` bucket and its read policy
6. `006_clip_range_check.sql`: clip range constraint
7. `007_stage8_hardening.sql`: job leases, the `storage_cleanup` queue, and deletion triggers

Each migration is written to run once. Don't re-run them on a database that already has them. To check that 007 is applied:
```sql
select column_name from information_schema.columns
where table_schema = 'public' and table_name = 'projects' and column_name = 'locked_until';
select count(*) from pg_trigger where tgname in ('projects_enqueue_storage', 'clips_enqueue_storage');  -- expect 2
```

### 3.2 Storage limits
Migration 002 sets the video bucket limit to 500 MB. Supabase's free plan caps files at 50 MB, so on the free plan lower `file_size_limit` in the bucket settings and set `NEXT_PUBLIC_MAX_UPLOAD_MB` to match.

### 3.3 Auth URLs
**Authentication > URL Configuration**
- **Site URL**: your frontend's public URL
- **Redirect URLs**: add `https://<your-frontend>/auth/callback` (and `http://localhost:3000/auth/callback` for development)

### 3.4 Google sign-in (optional)
**Authentication > Providers > Google**: enter a client ID and secret from Google Cloud Console. Add the callback URL Supabase shows to Google's authorized redirect URIs.

### 3.5 Email confirmation
Email sign-up sends a confirmation email by default. Keep it on in production.

### 3.6 Why the cleanup queue is in the database
Migration 007 adds triggers. When a project or clip row is deleted, by the API, by the browser, or by a cascade from deleting an auth user, the trigger writes the file paths into `storage_cleanup`. The backend deletes those files afterwards. This means files can't be orphaned by a deletion path that bypasses the API.

---

## 4. Redis (optional)

Redis is only needed to share rate limits between backend instances. With one instance, leave `REDIS_URL` empty and limits are counted in process memory.

- **Managed**: Upstash, Redis Cloud, or your host's Redis add-on. Use the URL they give you, `rediss://` for TLS.
- **Self-hosted**: `docker run -d --name redis -p 6379:6379 redis:7-alpine`, then `REDIS_URL=redis://localhost:6379/0`.

Behavior when Redis is down: requests are still limited, using each instance's own counts. Requests are not blocked and limits are not dropped. `/health` reports `rate_limit_store` as `redis` whenever `REDIS_URL` is set, which confirms the configuration but not that Redis is reachable. If you need reachability, check the backend logs for "Redis unavailable for rate limiting".

Redis holds only short-lived counters. Nothing is lost if it is restarted; counts restart at zero.

---

## 4a. Full stack with Docker Compose (single machine)

`docker-compose.yml` runs the web app, the API and Redis together. Supabase stays hosted.

```bash
cp backend/.env.example backend/.env   # SUPABASE_*, ANTHROPIC_API_KEY, FRONTEND_ORIGIN=http://localhost:3000
cp .env.example .env                   # NEXT_PUBLIC_* values for the web build
docker compose up --build
```

- Web: http://localhost:3000 · API: http://localhost:8000/health
- Redis is internal and is capped at 128 MB with `volatile-ttl` eviction, so rate-limit counters (which have expiry times) are the first thing dropped under pressure.
- Restart one service with `docker compose restart backend`. Stop everything with `docker compose down`.

For production, run the same containers on your platform, or deploy the web image and backend image separately. Keep `FRONTEND_ORIGIN` pointing at the public web origin.

## 5. Backend: Docker

### Build
From the `backend/` directory:
```bash
docker build -t clipforger-backend .
# Optional: bake the Whisper model into the image (larger image, no download on first start)
docker build --build-arg WHISPER_PRELOAD=small -t clipforger-backend:small .
```

The image is multi-stage. The build stage installs Python dependencies into a virtualenv. The runtime stage (`python:3.12-slim`) gets only that venv, the app code, the fonts, and `ffmpeg`. It runs as the non-root user `app` (UID 10001).

### Run
```bash
docker run -d --name clipforger-api \
  --env-file backend/.env \
  -p 8000:8000 \
  clipforger-backend
```

Keep secrets in `--env-file` or your platform's secret store. Don't pass them with `-e` on the command line, where they show up in shell history.

### Frontend container
The web app has its own image (`frontend/Dockerfile`, Next.js standalone output, non-root, health check on `/healthz`). Its `NEXT_PUBLIC_*` values are build arguments, since they are compiled into the browser bundle:
```bash
docker build -t clipforger-web \
  --build-arg NEXT_PUBLIC_SUPABASE_URL=https://<ref>.supabase.co \
  --build-arg NEXT_PUBLIC_SUPABASE_ANON_KEY=<anon key> \
  --build-arg NEXT_PUBLIC_API_URL=https://api.example.com \
  ./frontend
docker run -d -p 3000:3000 clipforger-web
```
Changing any `NEXT_PUBLIC_*` value means rebuilding the image.

The web app sends security headers on every response (`X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, and HSTS). It does not set a Content-Security-Policy, because a strict policy must allow the Supabase and API origins and needs testing in a real browser before it is enforced.

### Verify FFmpeg inside the container
```bash
docker run --rm clipforger-backend ffmpeg -hide_banner -version | head -1
docker run --rm clipforger-backend ffprobe -version | head -1
docker run --rm clipforger-backend sh -c 'ffmpeg -hide_banner -filters | grep -q " ass " && echo "libass: ok"'
```
The last check matters: captions are burned in with the `ass` filter, which needs libass.

### Health check
```bash
curl -fsS http://localhost:8000/health
# {"status":"ok","ffmpeg":true,"configured":true,"rate_limit_store":"redis"}
```
- `200` with `"status":"ok"`: ready
- `503` with `"status":"degraded"` and `"ffmpeg":false`: FFmpeg is missing, so the container is unusable. The Docker `HEALTHCHECK` marks it unhealthy and your orchestrator should restart it.
- `"configured":false`: a required environment variable is missing. The container logs which one.

The image's `HEALTHCHECK` runs this endpoint every 30 seconds.

---

## 6. Production deployment

### Recommended layout
- Frontend: Vercel (section 6a), or any Node host, with the `NEXT_PUBLIC_*` variables set
- Backend: one container service (Fly.io, Render, Google Cloud Run, ECS, or a VM with Docker), behind TLS
- Supabase: the hosted project
- Redis: a managed instance, if you run two or more backend containers

### Settings that must match across services
- `FRONTEND_ORIGIN` on the backend must be exactly the frontend's origin (scheme, host, port, no trailing slash). Otherwise the browser blocks API calls.
- `NEXT_PUBLIC_API_URL` on the frontend must be the backend's public HTTPS URL.
- The Supabase URL must be the same in both.

### Timeouts
Every backend request returns quickly: analysis and rendering run in the background, and the browser polls status every 3 seconds. A standard 60-second proxy timeout is enough. Video uploads go straight from the browser to Supabase Storage and never pass through the backend.

### Scaling
- Run one worker process per container (the image does this). Jobs run in the container's thread pool, so add containers to scale out, not workers.
- Several containers need `REDIS_URL` set for shared rate limits.
- Each container's pool is `PROCESSING_WORKERS`. Size the container's CPU and memory for that many concurrent FFmpeg and Whisper jobs. Whisper memory use depends on the model, so measure it with your chosen `WHISPER_MODEL` before you pick a container size.
- A job whose container dies is marked failed after its lease expires (`JOB_LEASE_SECONDS`, default 10 minutes). The user can then retry. The job is not resumed automatically.

### Job recovery and cleanup, in brief
- **Stale jobs**: each running job renews a lease every `HEARTBEAT_SECONDS`. If the lease expires, the job is marked failed with a message the user sees. This works across instances: a restart of one container doesn't affect jobs running in another.
- **Deletion**: `DELETE /projects/{id}` removes the rows first, then the files. Queued jobs for that project are cancelled. Running jobs stop at their next checkpoint and remove anything they uploaded after the delete. Files that can't be removed right away stay in `storage_cleanup`, and a background pass retries them with the error recorded.
- **Storage objects the cleanup pass won't touch**: source video and audio belonging to a project that still exists. Rendered clips are removed when their rows are replaced.

### Security checklist
- [ ] Service-role key only in backend secrets, never in `NEXT_PUBLIC_*` or the frontend repo
- [ ] `.env` files are not committed (`.gitignore` covers them, and `.dockerignore` keeps them out of the image)
- [ ] `FRONTEND_ORIGIN` is set to the real frontend origin, not `*`
- [ ] Rate limits set for your expected traffic (`RATE_LIMIT_*`)
- [ ] `REDIS_URL` uses `rediss://` (TLS) when it's on a network you don't fully control
- [ ] Supabase email confirmation is on
- [ ] Storage buckets remain private (`public = false`)
- [ ] Backend reached only over HTTPS

---

## 6a. Web app on Vercel (recommended)

Vercel hosts the **web app only**. The API cannot run on Vercel: it runs FFmpeg and Whisper, and its jobs take minutes, which is beyond Vercel's serverless limits. Host the backend on a container platform (section 6), and keep Supabase as is. Video uploads already go straight from the browser to Supabase Storage, so nothing large passes through Vercel.

### Step 1: Import the project
1. Push the repository to GitHub, GitLab or Bitbucket.
2. In Vercel, choose **Add New > Project** and import the repository.
3. Set **Root Directory** to `frontend`. This is required, because the repository holds the backend too.
4. Framework Preset: **Next.js** (detected automatically). Leave the install and build commands at their defaults; `frontend/vercel.json` sets them to `npm ci` and `npm run build`.
5. **Node.js version**: choose 20.x or 22.x in Project Settings > General. `package.json` requires 20.9 or newer.

### Step 2: Environment variables
Set these under **Project Settings > Environment Variables**, for **Production** and **Preview**:

| Name | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://<ref>.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | the **anon** key from Supabase > Project Settings > API |
| `NEXT_PUBLIC_API_URL` | the public `https://` URL of your backend |
| `NEXT_PUBLIC_MAX_UPLOAD_MB` | optional; must not exceed your Supabase bucket limit |

These are compiled into the public JavaScript at build time. After changing one, redeploy. Vercel does not need a server secret for the web app, so don't add the service-role key here.

The build checks this configuration and **fails with a clear message** if a required variable is missing, if `NEXT_PUBLIC_API_URL` is not HTTPS or points at localhost, or if the anon key is actually a service-role key. A deploy that would ship a broken app never reaches users.

### Step 3: Connect the backend
On the backend host, set:
- `FRONTEND_ORIGIN=https://<your-domain>` (comma-separate several origins, with no trailing slash)
- `FRONTEND_ORIGIN_REGEX` for preview deployments, which get a new URL per branch and commit. Restrict it to your own Vercel team slug:
  `^https://clipforger-[a-z0-9-]+-<your-team>\.vercel\.app$`
  Vercel's preview URL format can change, so test one preview against `/health` and the login page before relying on it.

Without these, the browser blocks every API call from the site, and the error shows as "Could not reach the processing server".

### Step 4: Supabase redirects
In **Authentication > URL Configuration**:
- **Site URL**: `https://<your-domain>`
- **Redirect URLs**: add `https://<your-domain>/auth/callback`, and for previews add the matching wildcard pattern for your team's `*.vercel.app` URLs. Check Supabase's current documentation for the exact wildcard syntax it accepts.

### Step 5: Domain and verification
1. Add your domain under **Settings > Domains**, and point DNS where Vercel tells you to.
2. Check these after the first production deploy:
   - `https://<your-domain>/healthz` returns `{"status":"ok"}`
   - `https://<your-domain>/dashboard` redirects to `/login` when signed out
   - Sign-up and login complete, and `/dashboard` loads for a signed-in user
   - Starting analysis on a project reaches the backend without a CORS error in the browser console

### Deploying from the command line (optional)
```bash
cd frontend
npx vercel link                 # choose the existing project
npx vercel --prod               # production deploy
```

### Vercel-specific notes
- The standalone server bundle is used only for the Docker image. Vercel builds its own deployment, so `next.config.js` turns standalone output off when `VERCEL` is set.
- Security headers come from `next.config.js` and are applied by Vercel to every response.
- Use Deployment Protection (Vercel's preview password or SSO) if preview deployments should stay private.
- Backend limits are not Vercel's limits. Set your container host's timeouts and memory for the workloads in sections 6 and 9.

## 7. Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Browser: "Could not reach the processing server" | Backend not running, `NEXT_PUBLIC_API_URL` wrong, or CORS: check `FRONTEND_ORIGIN` lists the exact frontend origin (or `FRONTEND_ORIGIN_REGEX` covers the preview URL). |
| Vercel build fails with "Build stopped: missing ..." | A `NEXT_PUBLIC_*` variable is not set in that environment. Add it in Vercel and redeploy. |
| Vercel build fails with "holds the service_role key" | The anon key variable contains the service-role key. Replace it with the anon key from Supabase. |
| `/health` returns 503, `"ffmpeg":false` | FFmpeg not installed in the image or on the host. Run the verification commands in section 5. |
| `"configured":false` in `/health` | `SUPABASE_URL` or `SUPABASE_SERVICE_ROLE_KEY` is missing. The startup log names the missing variable. |
| Every request returns 401 | Session expired (log in again), or the backend is pointed at a different Supabase project from the frontend. |
| Upload fails in the browser | Bucket limit lower than the file, or `NEXT_PUBLIC_MAX_UPLOAD_MB` larger than the bucket allows. See 3.2. |
| "Could not load your data … Have you run the SQL" | A migration is missing. Run them in order (section 3.1). |
| Project stuck on "processing" | A live job renews its lease, so it is never reaped. If the worker died, the lease expires after `JOB_LEASE_SECONDS` (10 min by default) and the project is marked failed with a message; then the user can retry. Don't set `JOB_LEASE_SECONDS` below `HEARTBEAT_SECONDS` × 3, or live jobs may be reaped by mistake. |
| "Too many requests. Try again in N minutes." (429) | The user hit a per-user limit. Raise the matching `RATE_LIMIT_*` value if it's too strict. The `Retry-After` header gives the wait in seconds. |
| `/health` shows `"rate_limit_store":"memory"` with several instances | `REDIS_URL` is missing or unreadable, so each instance counts separately. |
| "FFmpeg could not read this file" | The upload is corrupt or uses an unusual codec. Re-export as H.264 MP4. |
| "This video has no audio track" | Expected for silent video. Clipping needs speech. |
| "AI analysis is not configured" | `ANTHROPIC_API_KEY` is not set on the backend. |
| "AI analysis failed (401/403)" | The Anthropic key is invalid or lacks access to `LLM_MODEL`. |
| Whisper model download fails or is slow on first start | Use `WHISPER_PRELOAD` at build time, or a smaller `WHISPER_MODEL`. Check outbound access to Hugging Face. |
| Captions don't appear in the export | The FFmpeg build lacks libass. See the verification commands in section 5. |
| Deleted project's files still in Storage | Check `storage_cleanup` (see below). The maintenance pass retries every `MAINTENANCE_SECONDS`. |

Check the cleanup queue:
```sql
select bucket, path, attempts, last_error from public.storage_cleanup order by attempts, id;
```
Rows with `attempts` above 0 failed to delete. Read `last_error` (usually a permissions or network problem with Storage). The rows are retried automatically. Don't delete them by hand unless you have confirmed the files are gone.

Logs: the backend logs to stdout. Filter with `clipforger` for API events, `clipforger.pipeline` and `clipforger.render` for jobs, `clipforger.recovery` for stale-job recovery, `clipforger.cleanup` for storage cleanup.

---

## 8. Backups and data
- Enable Supabase point-in-time recovery on paid plans. Deleting a project is permanent.
- Rendered clips and source videos live only in Storage. Back them up if they matter to you.

---

## 9. Continuous integration

`.github/workflows/ci.yml` runs on every push and pull request:
- **backend**: pyflakes, then the full pytest suite with FFmpeg installed
- **frontend**: TypeScript check, `npm audit --omit=dev --audit-level=high` (fails the build on high or critical advisories), and a production build
- **containers**: builds both images, starts the API image and checks `/health`

Keep the audit gate on. If it fails, upgrade the affected package; don't remove the step.

## 10. What is and isn't verified

**Covered by automated tests (`backend/tests/`, run with `pytest`):**
- Authentication rejection, and ownership isolation between users
- Project creation, upload, processing, transcription hand-off and AI moment selection (AI stubbed)
- Clip generation, FFmpeg rendering at 9:16 with captions (real FFmpeg), output dimensions
- Preview data (`/words`), listings, and the trim validation rules
- Error handling: corrupt files, rendering before analysis, unreadable AI output
- Failed-job recovery: expired leases, legacy rows, heartbeats, stale renders, retried renders
- Deletion: rows, every storage object, cascades, owner-only, idempotent, cancelled queued jobs, deletion during analysis and during rendering, retries of failed storage deletes, and the sweeper's safety rules
- Rate limits: 429 with `Retry-After`, per-user isolation, polling limits, Redis counts shared across instances, fallback when Redis is down

**Not covered by automated tests:**
- A real browser session through the Next.js app (the production build succeeds, and TypeScript checks pass)
- A real Supabase project (the fake implements the protocol and triggers, but a production check of the migrations is still needed; section 3.1)
- Real Whisper transcription and real LLM output
- Building the Docker images. The CI workflow builds them, but this project's build environment had no Docker, so the image builds themselves have not been run here. The backend runtime was exercised directly, and the web app's standalone server was run with its security headers, health route and auth redirect checked.
- Load testing and upload performance at large file sizes
