import type { Metadata } from "next";
import "@fontsource-variable/bricolage-grotesque";
import "@fontsource-variable/inter";
import "./globals.css";

export const metadata: Metadata = {
  title: "Clipforger AI: Turn long videos into viral shorts",
  description: "Upload a long video. Clipforger transcribes it, finds the moments worth sharing, and exports captioned clips for Shorts, Reels and TikTok.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>);
}
