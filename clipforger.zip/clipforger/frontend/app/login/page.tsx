import AuthForm from "@/components/AuthForm";

export default function Login({ searchParams }: { searchParams: { error?: string } }) {
  return <AuthForm mode="login" initialError={searchParams.error ? "Sign-in could not be completed. Try again." : undefined} />;
}
