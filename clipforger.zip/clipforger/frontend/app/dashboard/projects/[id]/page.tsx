import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ProjectPlayer from "@/components/ProjectPlayer";
import ProcessPanel from "@/components/ProcessPanel";
import DeleteProject from "@/components/DeleteProject";
import { formatBytes, formatDuration } from "@/lib/format";

export default async function ProjectPage({ params }: { params: { id: string } }) {
  const supabase = await createClient();
  const { data: p } = await supabase.from("projects").select("*").eq("id", params.id).maybeSingle();
  if (!p) notFound();
  const { data: clips } = await supabase.from("clips")
    .select("id,title,category,score,reason,start_seconds,end_seconds,render_status,render_error,output_path").eq("project_id", params.id).order("score", { ascending: false });
  const { data: signed, error } = await supabase.storage.from("videos").createSignedUrl(p.storage_path, 3600);

  return (
    <div className="mx-auto max-w-3xl">
      <Link href="/dashboard" className="text-sm text-mist hover:text-white">Back to projects</Link>
      <h1 className="mt-3 font-display text-3xl font-semibold">{p.title}</h1>
      {signed ? (
        <ProjectPlayer projectId={p.id} url={signed.signedUrl} clips={clips ?? []} />
      ) : (
        <p role="alert" className="mt-6 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">Could not load the video: {error?.message}</p>
      )}
      <dl className="mt-6 grid grid-cols-3 gap-3 text-sm">
        <div className="rounded-xl border border-line bg-coal p-4"><dt className="text-mist">Status</dt><dd className="mt-1">{p.status}</dd></div>
        <div className="rounded-xl border border-line bg-coal p-4"><dt className="text-mist">Size</dt><dd className="mt-1">{formatBytes(p.size_bytes)}</dd></div>
        <div className="rounded-xl border border-line bg-coal p-4"><dt className="text-mist">Duration</dt><dd className="mt-1">{formatDuration(p.duration_seconds)}</dd></div>
      </dl>
      <ProcessPanel clipCount={clips?.length ?? 0} projectId={p.id} initial={{ status: p.status, processing_step: p.processing_step, error_message: p.error_message }} />
      <DeleteProject projectId={p.id} title={p.title} />
    </div>
  );
}
