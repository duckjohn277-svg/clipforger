import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ClipEditor from "@/components/ClipEditor";

export default async function EditorPage({ params }: { params: { id: string; clipId: string } }) {
  const supabase = await createClient();
  const { data: p } = await supabase.from("projects").select("id,title,storage_path,duration_seconds").eq("id", params.id).maybeSingle();
  const { data: clip } = await supabase.from("clips").select("*").eq("id", params.clipId).eq("project_id", params.id).maybeSingle();
  if (!p || !clip) notFound();
  const { data: signed } = await supabase.storage.from("videos").createSignedUrl(p.storage_path, 3600);
  if (!signed) notFound();
  return (
    <ClipEditor projectId={p.id} projectTitle={p.title} videoUrl={signed.signedUrl}
      sourceDuration={Number(p.duration_seconds ?? Number(clip.end_seconds) + 60)}
      clip={{ id: clip.id, title: clip.title, start: Number(clip.start_seconds), end: Number(clip.end_seconds),
        render_status: clip.render_status, render_error: clip.render_error, output_path: clip.output_path, render_options: clip.render_options }} />
  );
}
