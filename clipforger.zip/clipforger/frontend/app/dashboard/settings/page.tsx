import { createClient } from "@/lib/supabase/server";

export default async function Settings() {
  const { data: { user } } = await (await createClient()).auth.getUser();
  const provider = user?.app_metadata?.provider ?? "email";
  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-3xl font-semibold">Account settings</h1>
      <dl className="mt-8 divide-y divide-line rounded-2xl border border-line bg-coal">
        {[["Email", user?.email ?? ""], ["Sign-in method", provider], ["Member since", user?.created_at ? new Date(user.created_at).toLocaleDateString() : ""]].map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 px-5 py-4"><dt className="text-mist">{k}</dt><dd>{v}</dd></div>))}
      </dl>
    </div>
  );
}
