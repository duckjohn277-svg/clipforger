import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Logo } from "@/components/Nav";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { data: { user } } = await (await createClient()).auth.getUser();
  if (!user) redirect("/login");
  const link = "rounded-lg px-3 py-2 text-sm text-mist transition hover:bg-slate2 hover:text-white";
  return (
    <div className="min-h-screen md:grid md:grid-cols-[220px_1fr]">
      <aside className="flex items-center justify-between gap-4 border-b border-line bg-coal px-4 py-3 md:flex-col md:items-stretch md:justify-start md:border-b-0 md:border-r md:p-5">
        <div className="md:mb-6"><Logo /></div>
        <nav className="flex gap-1 md:flex-col" aria-label="Dashboard">
          <Link href="/dashboard" className={link}>Projects</Link>
          <Link href="/dashboard/settings" className={link}>Settings</Link>
        </nav>
        <form action="/auth/signout" method="post" className="md:mt-auto">
          <button className={`${link} w-full text-left`}>Log out</button>
        </form>
      </aside>
      <main className="min-w-0 px-5 py-8 md:px-10">{children}</main>
    </div>
  );
}
