import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

const statusStyle: Record<string, string> = {
  uploaded: "bg-slate2 text-mist", processing: "bg-violet-600/20 text-violet-400",
  ready: "bg-emerald-500/15 text-emerald-300", audio_ready: "bg-emerald-500/15 text-emerald-300", failed: "bg-red-500/15 text-red-300",
};

export default async function Dashboard() {
  const supabase = await createClient();
  const [projects, clips, profile] = await Promise.all([
    supabase.from("projects").select("id,title,status,duration_seconds,created_at").order("created_at", { ascending: false }).limit(8),
    supabase.from("clips").select("id", { count: "exact", head: true }),
    supabase.from("profiles").select("plan").maybeSingle(),
  ]);
  const err = projects.error || clips.error;
  const list = projects.data ?? [];
  const minutes = Math.round(list.reduce((s, p) => s + (p.duration_seconds ?? 0), 0) / 60);
  const processing = list.filter((p) => p.status === "processing").length;
  const stats = [["Projects", String(list.length)], ["Clips generated", String(clips.count ?? 0)], ["Minutes uploaded", String(minutes)], ["Processing now", String(processing)]];

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-semibold">Projects</h1>
        <Link href="/dashboard/upload" className="rounded-full bg-violet-600 px-5 py-2.5 text-sm font-medium transition hover:bg-violet-500">Upload video</Link>
      </div>
      {err && <p role="alert" className="mt-6 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">
        Could not load your data: {err.message}. Have you run the SQL in supabase/migrations?</p>}
      <dl className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-xl border border-line bg-coal p-4">
            <dt className="text-sm text-mist">{k}</dt><dd className="mt-1 font-display text-3xl font-semibold">{v}</dd>
          </div>))}
      </dl>
      <section className="mt-10" aria-labelledby="recent">
        <h2 id="recent" className="font-display text-xl font-medium">Recent projects</h2>
        {list.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-dashed border-line p-10 text-center text-mist">
            No projects yet. Upload a video to get started.
          </div>
        ) : (
          <ul className="mt-4 divide-y divide-line rounded-2xl border border-line bg-coal">
            {list.map((p) => (
              <li key={p.id}>
                <Link href={`/dashboard/projects/${p.id}`} className="flex items-center justify-between gap-4 px-5 py-4 transition hover:bg-slate2">
                  <span className="truncate font-medium">{p.title}</span>
                  <span className={`rounded-full px-3 py-1 text-xs ${statusStyle[p.status] ?? statusStyle.uploaded}`}>{p.status}</span>
                </Link>
              </li>))}
          </ul>
        )}
      </section>
      <section className="mt-10 rounded-2xl border border-line bg-coal p-5">
        <h2 className="font-display text-xl font-medium">Subscription</h2>
        <p className="mt-2 text-mist">You are on the <span className="text-white">{profile.data?.plan ?? "free"}</span> plan. Billing is not set up yet.</p>
      </section>
    </div>
  );
}
