// Liveness probe for the container and load balancer. Deliberately does no upstream calls,
// so a Supabase or API outage doesn't make the web tier look dead.
export const dynamic = "force-dynamic";

export function GET() {
  return Response.json({ status: "ok" });
}
