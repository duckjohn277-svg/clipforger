import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

// Next.js 15+ makes cookies() async, so this factory is async too. Await it in every server caller.
export async function createClient() {
  const store = await cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => store.getAll(),
      setAll(list) {
        try { list.forEach(({ name, value, options }) => store.set(name, value, options)); } catch { /* called from a Server Component; the proxy refreshes the session */ }
      },
    },
  });
}
