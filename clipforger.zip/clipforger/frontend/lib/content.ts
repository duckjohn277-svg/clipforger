export const features = [
  { title: "Finds moments, not random cuts", body: "Whisper transcribes every word, then a language model scores the transcript for hooks, funny beats, teachable points and strong statements." },
  { title: "Clips end on a finished thought", body: "Start and end times snap to sentence boundaries, so a clip never opens mid-word or stops halfway through an idea." },
  { title: "Captions that hold attention", body: "Word-level timing, animated presets, highlighted keywords, and full control over size and position." },
  { title: "Edit in the browser", body: "Trim, switch aspect ratio, restyle captions and preview the final render before you export." },
  { title: "Every platform, one export", body: "9:16 for Shorts, Reels and TikTok, 1:1 for feeds, 16:9 for everything else. Rendered to MP4 with FFmpeg." },
  { title: "Built for long videos", body: "Processing runs in the background. Close the tab and your clips will be waiting in the dashboard." },
];
export const steps = [
  { title: "Upload", body: "Drop in an MP4 or MOV. You see file size, duration and a preview before anything is processed." },
  { title: "Analyze", body: "Audio is extracted and transcribed with word-level timestamps." },
  { title: "Generate clips", body: "The AI proposes clips ranked by how strong the hook and payoff are, each with a reason." },
  { title: "Edit", body: "Trim, restyle captions, pick an aspect ratio." },
  { title: "Export", body: "Download high-quality MP4 files, ready to post." },
];
export const plans = [
  { name: "Free", price: "$0", note: "to try it out", cta: "Start free", featured: false,
    items: ["60 minutes of video per month", "Up to 10 clips per month", "Captions in 1 style", "720p export"] },
  { name: "Creator", price: "$24", note: "per month", cta: "Choose Creator", featured: true,
    items: ["600 minutes of video per month", "Unlimited clips", "All caption styles", "1080p export, all aspect ratios", "Videos up to 2 hours"] },
  { name: "Studio", price: "$79", note: "per month", cta: "Choose Studio", featured: false,
    items: ["2,400 minutes of video per month", "Unlimited clips", "Priority processing", "1080p export, all aspect ratios", "Videos up to 4 hours"] },
];
export const faqs = [
  { q: "Which video formats can I upload?", a: "MP4 and MOV. File size and length limits depend on your plan, and you get a clear message if a file is over the limit." },
  { q: "How does Clipforger choose clips?", a: "It transcribes the video with Whisper, then asks a language model to find complete moments with a strong opening, a clear payoff, and something worth sharing. Each clip comes with the reason it was picked." },
  { q: "Can I change the clips it generates?", a: "Yes. Trim the start and end, change the aspect ratio, restyle the captions, and preview the result before exporting." },
  { q: "Do I own the clips?", a: "Yes. Your uploads and exported clips belong to you." },
  { q: "How long does processing take?", a: "It depends on video length and queue load. Processing runs in the background, and the dashboard shows the status of each project." },
];
