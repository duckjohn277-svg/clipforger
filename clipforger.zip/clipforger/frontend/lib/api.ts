import { createClient } from "@/lib/supabase/client";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export async function api<T = any>(path: string, method = "GET", body?: unknown): Promise<T> {
  const { data: { session } } = await createClient().auth.getSession();
  if (!session) throw new Error("Your session expired. Log in again.");
  let res: Response;
  try {
    res = await fetch(`${API}${path}`, {
      method, body: body ? JSON.stringify(body) : undefined,
      headers: { Authorization: `Bearer ${session.access_token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
    });
  } catch { throw new Error("Could not reach the processing server. Is the backend running?"); }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(typeof json.detail === "string" ? json.detail : `Request failed (${res.status}).`);
  return json;
}
