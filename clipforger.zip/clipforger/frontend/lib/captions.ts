// Mirrors backend/app/captions.py so the editor preview groups and highlights words the way the render will.
export type Word = { start: number; end: number; word: string };
export type Chunk = { words: Word[]; start: number; end: number };
export const STYLES = ["karaoke", "bold", "pop", "minimal"] as const;
export type CaptionStyle = (typeof STYLES)[number];

const STOP = new Set(`about above after again against also because been before being below between both but could did does doing down
during each from further have having here hers herself himself into itself just like more most myself once only other ours
ourselves over same should some such than that their theirs them themselves then there these they this those through under
until very was were what when where which while who whom whose will with would your yours yourself yourselves really actually
gonna kind sort thing things know going think because people`.split(/\s+/));
const END = /[.!?,;:]$/;
const MAX_WORDS: Record<CaptionStyle, number> = { bold: 4, karaoke: 4, pop: 1, minimal: 7 };
const core = (w: string) => w.replace(/[^\p{L}\p{N}_]/gu, "");

export function keywordIndex(chunk: string[]): number | null {
  const n = chunk.findIndex((w) => /\p{N}/u.test(w));
  if (n >= 0) return n;
  let best: number | null = null;
  chunk.forEach((w, i) => {
    const c = core(w).toLowerCase();
    if (c.length >= 5 && !STOP.has(c) && (best === null || c.length > core(chunk[best]).length)) best = i;
  });
  return best;
}

export function chunkWords(words: Word[], maxWords: number, gap = 0.6): Word[][] {
  const out: Word[][] = [];
  let cur: Word[] = [];
  words.forEach((w, i) => {
    cur.push(w);
    const nxt = words[i + 1];
    if (cur.length >= maxWords || END.test(w.word) || (nxt && nxt.start - w.end > gap)) { out.push(cur); cur = []; }
  });
  if (cur.length) out.push(cur);
  return out;
}

export function buildChunks(words: Word[], style: CaptionStyle): Chunk[] {
  const ws = words.map((w) => ({ ...w, word: w.word.replace(/[{}\\]/g, "") })).filter((w) => w.word);
  const chunks = chunkWords(ws, MAX_WORDS[style]);
  return chunks.map((c, i) => {
    const start = c[0].start;
    let end = c[c.length - 1].end;
    const nxt = chunks[i + 1]?.[0].start;
    if (nxt !== undefined && nxt - end >= 0 && nxt - end < 0.3) end = nxt;
    return { words: c, start, end: Math.max(end, start + 0.12) };
  });
}
