/** @type {import("next").NextConfig} */

const REQUIRED = ["NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_ANON_KEY", "NEXT_PUBLIC_API_URL"];

// Read the "role" claim of a Supabase key without verifying it. Used only to catch a service key pasted by mistake.
function jwtRole(token) {
  try {
    return JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString("utf8")).role;
  } catch {
    return undefined;
  }
}

// Runs at build time. NEXT_PUBLIC_* values are compiled into the public JavaScript, so a wrong value
// shipped to users cannot be fixed without a rebuild. Fail the build instead of shipping a broken app.
function checkBuildEnv() {
  if (process.env.NODE_ENV !== "production") return; // `next dev` and tooling are not checked
  const missing = REQUIRED.filter((k) => !process.env[k]);
  if (missing.length) {
    throw new Error(`Build stopped: missing ${missing.join(", ")}. Set them in Vercel (Project Settings > Environment Variables) or in your build arguments.`);
  }
  if (jwtRole(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) === "service_role") {
    throw new Error("NEXT_PUBLIC_SUPABASE_ANON_KEY holds the service_role key. Use the anon key. The service key must never reach the browser.");
  }
  if (!/^https:\/\//.test(process.env.NEXT_PUBLIC_API_URL) && process.env.VERCEL) {
    throw new Error(`NEXT_PUBLIC_API_URL must be an https:// URL on Vercel, got "${process.env.NEXT_PUBLIC_API_URL}".`);
  }
  if (process.env.VERCEL && /localhost|127\.0\.0\.1/.test(process.env.NEXT_PUBLIC_API_URL)) {
    throw new Error("NEXT_PUBLIC_API_URL points at localhost. Set it to the public URL of the backend.");
  }
}
checkBuildEnv();

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
];

module.exports = {
  reactStrictMode: true,
  // Vercel builds its own deployment, so the standalone bundle is only for the Docker image.
  ...(process.env.VERCEL ? {} : { output: "standalone" }),
  poweredByHeader: false,
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};
