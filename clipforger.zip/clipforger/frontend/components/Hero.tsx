"use client";
import Link from "next/link";
import { motion } from "framer-motion";

const bars = Array.from({ length: 96 }, (_, i) => 6 + Math.round(Math.abs(Math.sin(i * 1.7) * Math.cos(i * 0.45)) * 34));
const picks = [
  { from: 14, to: 24, label: "Hook", score: 96 },
  { from: 44, to: 55, label: "Funny", score: 91 },
  { from: 72, to: 84, label: "Insight", score: 88 },
];
const inPick = (i: number) => picks.findIndex((p) => i >= p.from && i < p.to);

export default function Hero() {
  return (
    <section className="relative overflow-hidden px-5 pb-24 pt-20 sm:pt-28">
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-violet-600/20 blur-[120px]" />
      <div className="relative mx-auto max-w-4xl text-center">
        <h1 className="font-display text-5xl font-semibold leading-[1.02] tracking-tight sm:text-7xl">
          Turn long videos into viral shorts.
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg text-mist">
          Upload a podcast, interview or lecture. Clipforger transcribes it, finds the moments worth sharing, and exports captioned clips for YouTube Shorts, Instagram Reels and TikTok.
        </p>
        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link href="/signup" className="w-full rounded-full bg-violet-600 px-7 py-3.5 font-medium transition hover:bg-violet-500 sm:w-auto">Get started free</Link>
          <a href="#how-it-works" className="w-full rounded-full border border-line px-7 py-3.5 font-medium text-white/90 transition hover:border-violet-400 sm:w-auto">Watch demo</a>
        </div>
      </div>

      <div className="relative mx-auto mt-20 max-w-5xl rounded-2xl border border-line bg-coal p-4 shadow-[0_40px_120px_-40px_rgba(124,58,237,0.5)] sm:p-6">
        <div className="mb-5 flex items-center justify-between text-sm">
          <span className="font-medium">founder-interview-ep42.mp4</span>
          <span className="rounded-full bg-violet-600/15 px-3 py-1 text-xs text-violet-400">3 clips found in 1h 12m</span>
        </div>
        <div className="flex h-[88px] items-center gap-[3px]" role="img" aria-label="Waveform of a long video with three highlighted clip segments">
          {bars.map((h, i) => (
            <motion.span key={i} initial={{ scaleY: 0.2, opacity: 0.4 }} animate={{ scaleY: 1, opacity: 1 }}
              transition={{ delay: i * 0.008, duration: 0.5 }}
              style={{ height: h * 2 }}
              className={`flex-1 rounded-full ${inPick(i) >= 0 ? "bg-violet-500" : "bg-slate2"}`} />
          ))}
        </div>
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {picks.map((p, i) => (
            <motion.div key={p.label} initial={{ y: 16, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.9 + i * 0.12 }}
              className="flex items-center gap-4 rounded-xl border border-line bg-ink p-3">
              <div className="grid h-24 w-14 shrink-0 place-items-end rounded-lg bg-gradient-to-b from-slate2 to-violet-600/40 p-1.5">
                <span className="w-full rounded bg-black/60 py-0.5 text-center text-[9px] font-semibold">CAPTION</span>
              </div>
              <div className="min-w-0">
                <p className="font-medium">{p.label}</p>
                <p className="text-sm text-mist">Score {p.score} · 9:16</p>
              </div>
            </motion.div>
          ))}
        </div>
        <p className="mt-4 text-xs text-mist">Illustrative preview. Real clip detection is built in Stage 5.</p>
      </div>
    </section>
  );
}
