"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { MAX_UPLOAD_MB, formatBytes, formatDuration } from "@/lib/format";

const TYPES: Record<string, string> = { mp4: "video/mp4", mov: "video/quicktime" };
const extOf = (name: string) => name.split(".").pop()?.toLowerCase() ?? "";

function validate(f: File): string | null {
  if (!TYPES[extOf(f.name)]) return "Unsupported file type. Upload an MP4 or MOV video.";
  if (f.size === 0) return "This file is empty.";
  if (f.size > MAX_UPLOAD_MB * 1024 * 1024)
    return `This file is ${formatBytes(f.size)}. The upload limit is ${MAX_UPLOAD_MB} MB.`;
  return null;
}

export default function Uploader() {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const xhr = useRef<XMLHttpRequest | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [duration, setDuration] = useState<number | null>(null);
  const [previewFailed, setPreviewFailed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const uploading = progress !== null;

  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);

  const pick = useCallback((f?: File) => {
    if (!f) return;
    setError(null); setDuration(null); setPreviewFailed(false);
    const problem = validate(f);
    if (problem) { setFile(null); setUrl(null); setError(problem); return; }
    setFile(f); setUrl(URL.createObjectURL(f));
  }, []);

  function send(path: string, token: string, f: File) {
    return new Promise<void>((resolve, reject) => {
      const req = new XMLHttpRequest();
      xhr.current = req;
      req.open("POST", `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/videos/${path}`);
      req.setRequestHeader("Authorization", `Bearer ${token}`);
      req.setRequestHeader("apikey", process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
      req.setRequestHeader("x-upsert", "false");
      req.setRequestHeader("Content-Type", TYPES[extOf(f.name)]);
      req.upload.onprogress = (e) => e.lengthComputable && setProgress(Math.round((e.loaded / e.total) * 100));
      req.onload = () => {
        if (req.status >= 200 && req.status < 300) return resolve();
        let msg = `Upload failed (${req.status}).`;
        try { const j = JSON.parse(req.responseText); msg = j.message || j.error || msg; } catch {}
        reject(new Error(msg));
      };
      req.onerror = () => reject(new Error("Network error. Check your connection and try again."));
      req.onabort = () => reject(new Error("cancelled"));
      req.send(f);
    });
  }

  async function upload() {
    if (!file) return;
    setError(null); setProgress(0);
    const supabase = createClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { setProgress(null); setError("Your session expired. Log in again."); return; }
    const path = `${session.user.id}/${crypto.randomUUID()}.${extOf(file.name)}`;
    try {
      await send(path, session.access_token, file);
      const { data, error: dbErr } = await supabase.from("projects").insert({
        user_id: session.user.id, title: file.name.replace(/\.[^.]+$/, ""), status: "uploaded",
        duration_seconds: duration, size_bytes: file.size, storage_path: path,
      }).select("id").single();
      if (dbErr || !data) {
        await supabase.storage.from("videos").remove([path]);
        throw new Error(dbErr?.message ?? "Could not save the project.");
      }
      router.push(`/dashboard/projects/${data.id}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Upload failed.";
      if (msg !== "cancelled") setError(msg);
      setProgress(null);
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-3xl font-semibold">Upload a video</h1>
      <p className="mt-2 text-mist">MP4 or MOV, up to {MAX_UPLOAD_MB} MB.</p>

      {!file && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); pick(e.dataTransfer.files[0]); }}
          className={`mt-6 grid place-items-center rounded-2xl border-2 border-dashed p-12 text-center transition ${dragging ? "border-violet-400 bg-violet-600/10" : "border-line bg-coal"}`}>
          <p className="font-medium">Drag a video here</p>
          <button type="button" onClick={() => input.current?.click()} className="mt-4 rounded-full border border-line px-5 py-2 text-sm transition hover:border-violet-400">Choose a file</button>
          <input ref={input} type="file" accept=".mp4,.mov,video/mp4,video/quicktime" className="sr-only" aria-label="Choose a video file"
            onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
        </div>
      )}

      {error && <p role="alert" className="mt-4 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}

      {file && url && (
        <div className="mt-6 rounded-2xl border border-line bg-coal p-4">
          {previewFailed ? (
            <p className="rounded-lg bg-ink p-6 text-sm text-mist">Your browser can’t preview this file, but it can still be uploaded. Duration will be read during processing.</p>
          ) : (
            <video src={url} controls preload="metadata" className="max-h-[420px] w-full rounded-lg bg-black"
              onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)} onError={() => setPreviewFailed(true)} />
          )}
          <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
            <div className="col-span-3 sm:col-span-1"><dt className="text-mist">File</dt><dd className="truncate">{file.name}</dd></div>
            <div><dt className="text-mist">Size</dt><dd>{formatBytes(file.size)}</dd></div>
            <div><dt className="text-mist">Duration</dt><dd>{formatDuration(duration)}</dd></div>
          </dl>
          {uploading && (
            <div className="mt-4" role="progressbar" aria-valuenow={progress ?? 0} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-2 overflow-hidden rounded-full bg-slate2"><div className="h-full bg-violet-500 transition-all" style={{ width: `${progress}%` }} /></div>
              <p className="mt-2 text-sm text-mist">{progress === 100 ? "Saving project…" : `Uploading… ${progress}%`}</p>
            </div>
          )}
          <div className="mt-4 flex gap-3">
            {uploading ? (
              <button onClick={() => xhr.current?.abort()} className="rounded-full border border-line px-5 py-2.5 text-sm hover:border-violet-400">Cancel upload</button>
            ) : (<>
              <button onClick={upload} className="rounded-full bg-violet-600 px-6 py-2.5 text-sm font-medium transition hover:bg-violet-500">Upload video</button>
              <button onClick={() => { setFile(null); setUrl(null); setError(null); }} className="rounded-full border border-line px-5 py-2.5 text-sm hover:border-violet-400">Choose another</button>
            </>)}
          </div>
        </div>
      )}
    </div>
  );
}
