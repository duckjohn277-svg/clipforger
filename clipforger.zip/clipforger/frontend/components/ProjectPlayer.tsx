"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";
import { createClient } from "@/lib/supabase/client";
import { formatDuration } from "@/lib/format";

export type Clip = {
  id: string; title: string | null; category: string | null; score: number | null; reason: string | null;
  start_seconds: number; end_seconds: number; render_status: string; render_error: string | null; output_path: string | null;
};
type Status = Pick<Clip, "id" | "render_status" | "render_error" | "output_path">;

const STYLES = [["karaoke", "Karaoke (active word lit)"], ["bold", "Bold"], ["pop", "Pop (one word)"], ["minimal", "Minimal box"]];
const ASPECTS = [["9:16", "Vertical 9:16"], ["1:1", "Square 1:1"], ["16:9", "Landscape 16:9"]];
const busy = (s: string) => s === "queued" || s === "rendering";
const select = "rounded-lg border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-violet-500";

export default function ProjectPlayer({ projectId, url, clips: initial }: { projectId: string; url: string; clips: Clip[] }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [clips, setClips] = useState(initial);
  const [active, setActive] = useState<Clip | null>(null);
  const [watching, setWatching] = useState<{ id: string; url: string } | null>(null);
  const [style, setStyle] = useState("karaoke");
  const [aspect, setAspect] = useState("9:16");
  const [captionsOn, setCaptionsOn] = useState(true);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const anyBusy = clips.some((c) => busy(c.render_status));

  useEffect(() => {
    if (!anyBusy) return;
    const t = setInterval(async () => {
      try {
        const rows: Status[] = await api(`/projects/${projectId}/clips`);
        setClips((cs) => cs.map((c) => ({ ...c, ...(rows.find((r) => r.id === c.id) ?? {}) })));
      } catch (e) { setError(e instanceof Error ? e.message : "Lost contact with the server."); }
    }, 3000);
    return () => clearInterval(t);
  }, [anyBusy, projectId]);

  async function renderAll() {
    setError(null); setStarting(true);
    try {
      await api(`/projects/${projectId}/render`, "POST", { aspect, captions: { enabled: captionsOn, style } });
      setClips((cs) => cs.map((c) => (busy(c.render_status) ? c : { ...c, render_status: "queued", render_error: null })));
    } catch (e) { setError(e instanceof Error ? e.message : "Could not start rendering."); }
    finally { setStarting(false); }
  }

  async function signed(c: Clip, download?: string) {
    const { data, error } = await createClient().storage.from("clips").createSignedUrl(c.output_path!, 3600, download ? { download } : undefined);
    if (error || !data) { setError("Could not open the rendered clip."); return null; }
    return data.signedUrl;
  }

  function preview(c: Clip) {
    const v = ref.current;
    if (!v) return;
    v.currentTime = Number(c.start_seconds); void v.play(); setActive(c);
    v.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  return (
    <>
      <video ref={ref} src={url} controls preload="metadata" className="mt-6 max-h-[480px] w-full rounded-xl bg-black"
        onTimeUpdate={() => { const v = ref.current; if (v && active && v.currentTime >= Number(active.end_seconds)) { v.pause(); setActive(null); } }} />
      {clips.length > 0 && (
        <section className="mt-8" aria-labelledby="clips">
          <h2 id="clips" className="font-display text-xl font-medium">Suggested clips</h2>
          <div className="mt-4 flex flex-wrap items-end gap-3 rounded-xl border border-line bg-coal p-4">
            <label className="text-sm text-mist">Format<br /><select value={aspect} onChange={(e) => setAspect(e.target.value)} className={select}>{ASPECTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
            <label className="text-sm text-mist">Caption style<br /><select value={style} disabled={!captionsOn} onChange={(e) => setStyle(e.target.value)} className={`${select} disabled:opacity-40`}>{STYLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
            <label className="flex items-center gap-2 pb-2 text-sm"><input type="checkbox" checked={captionsOn} onChange={(e) => setCaptionsOn(e.target.checked)} className="accent-violet-500" />Captions</label>
            <button onClick={renderAll} disabled={starting || anyBusy} className="ml-auto rounded-full bg-violet-600 px-5 py-2.5 text-sm font-medium transition hover:bg-violet-500 disabled:opacity-50">
              {starting ? "Starting…" : anyBusy ? "Rendering…" : "Render all clips"}
            </button>
          </div>
          {error && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}
          <ul className="mt-4 space-y-3">
            {clips.map((c) => (
              <li key={c.id} className={`rounded-xl border p-4 ${active?.id === c.id ? "border-violet-500 bg-violet-600/10" : "border-line bg-coal"}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <p className="font-medium">{c.title}</p>
                    <p className="mt-1 text-sm text-mist">{c.reason}</p>
                    <p className="mt-2 text-xs text-mist">{c.category} · {formatDuration(c.start_seconds)} to {formatDuration(c.end_seconds)} · {Math.round(c.end_seconds - c.start_seconds)}s</p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-2">
                    <span className="rounded-full bg-violet-600/20 px-3 py-1 text-xs text-violet-400">Score {c.score}</span>
                    <button onClick={() => preview(c)} className="rounded-full border border-line px-4 py-1.5 text-sm transition hover:border-violet-400">Preview source</button>
                    <Link href={`/dashboard/projects/${projectId}/clips/${c.id}`} className="rounded-full border border-violet-500 px-4 py-1.5 text-sm text-violet-400 transition hover:bg-violet-600/15">Edit and export</Link>
                  </div>
                </div>
                {c.render_status !== "none" && (
                  <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-line pt-3 text-sm" aria-live="polite">
                    {busy(c.render_status) && <span className="flex items-center gap-2 text-mist"><span aria-hidden className="h-2 w-2 animate-pulse rounded-full bg-violet-500" />{c.render_status === "queued" ? "Queued" : "Rendering"}…</span>}
                    {c.render_status === "failed" && <span role="alert" className="text-red-300">{c.render_error ?? "Rendering failed."}</span>}
                    {c.render_status === "done" && c.output_path && (<>
                      <span className="text-emerald-300">Rendered</span>
                      <button onClick={async () => { const u = await signed(c); if (u) setWatching(watching?.id === c.id ? null : { id: c.id, url: u }); }} className="rounded-full border border-line px-4 py-1.5 transition hover:border-violet-400">{watching?.id === c.id ? "Hide" : "Watch"}</button>
                      <button onClick={async () => { const u = await signed(c, `${(c.title ?? "clip").replace(/[^\w -]/g, "")}.mp4`); if (u) location.assign(u); }} className="rounded-full border border-line px-4 py-1.5 transition hover:border-violet-400">Download</button>
                    </>)}
                  </div>
                )}
                {watching?.id === c.id && <video src={watching.url} controls autoPlay className="mt-3 max-h-[520px] rounded-lg bg-black" />}
              </li>
            ))}
          </ul>
        </section>
      )}
    </>
  );
}
