import { Logo } from "./Nav";

export default function Footer() {
  return (
    <footer className="border-t border-line px-5 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
        <Logo />
        <p className="text-sm text-mist">© {new Date().getFullYear()} Clipforger AI</p>
      </div>
    </footer>
  );
}
