"use client";
import "@fontsource/anton";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/lib/api";
import { createClient } from "@/lib/supabase/client";
import { buildChunks, keywordIndex, STYLES, type CaptionStyle, type Word } from "@/lib/captions";

type RenderState = { render_status: string; render_error: string | null; output_path: string | null };
type Props = {
  projectId: string; projectTitle: string; videoUrl: string; sourceDuration: number;
  clip: RenderState & { id: string; title: string | null; start: number; end: number; render_options: any };
};

const MIN_LEN = 3, MAX_LEN = 180;
const FRAME: Record<string, { ratio: string; max: string }> = { "9:16": { ratio: "9 / 16", max: "300px" }, "1:1": { ratio: "1 / 1", max: "420px" }, "16:9": { ratio: "16 / 9", max: "100%" } };
const STYLE_LABELS: Record<CaptionStyle, string> = { karaoke: "Karaoke", bold: "Bold", pop: "Pop", minimal: "Minimal box" };
const fmt = (t: number) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, "0")}`;
const busy = (s: string) => s === "queued" || s === "rendering";
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const field = "rounded-lg border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-violet-500";
const btn = "rounded-full border border-line px-4 py-1.5 text-sm transition hover:border-violet-400";

export default function ClipEditor({ projectId, projectTitle, videoUrl, sourceDuration, clip }: Props) {
  const ro = clip.render_options ?? {}, rc = ro.captions ?? {};
  const wMin = Math.max(0, clip.start - 60), wMax = Math.min(sourceDuration, clip.end + 60);
  const video = useRef<HTMLVideoElement>(null), bg = useRef<HTMLVideoElement>(null);

  const [start, setStart] = useState(clip.start), [end, setEnd] = useState(clip.end);
  const [aspect, setAspect] = useState<string>(ro.aspect ?? "9:16"), [fit, setFit] = useState<string>(ro.fit ?? "fill");
  const [on, setOn] = useState<boolean>(rc.enabled ?? true), [style, setStyle] = useState<CaptionStyle>(rc.style ?? "karaoke");
  const [size, setSize] = useState<number>(rc.font_size_pct ?? 9), [position, setPosition] = useState<string>(rc.position ?? "bottom");
  const [offset, setOffset] = useState<number>(rc.offset_pct ?? 14), [highlight, setHighlight] = useState<boolean>(rc.highlight_keywords ?? true);
  const [words, setWords] = useState<Word[]>([]), [t, setT] = useState(clip.start), [playing, setPlaying] = useState(false);
  const [status, setStatus] = useState<RenderState>(clip);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false), [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api(`/projects/${projectId}/words?start=${wMin}&end=${wMax}`).then(setWords)
      .catch((e) => setError(e instanceof Error ? `Captions unavailable: ${e.message}` : "Captions unavailable."));
  }, [projectId, wMin, wMax]);

  useEffect(() => { if (video.current) video.current.currentTime = clip.start; }, [clip.start]);

  const chunks = useMemo(() => buildChunks(words.filter((w) => w.end > start && w.start < end), style), [words, start, end, style]);
  const chunk = on ? chunks.find((c) => t >= c.start && t < c.end) : undefined;
  const kw = chunk && highlight && style !== "pop" ? keywordIndex(chunk.words.map((w) => w.word)) : null;
  const activeIdx = chunk ? chunk.words.reduce((a, w, i) => (w.start <= t ? i : a), 0) : 0;

  // Poll while an export is running, then load the rendered file.
  useEffect(() => {
    if (!busy(status.render_status)) return;
    const i = setInterval(async () => {
      try {
        const rows: (RenderState & { id: string })[] = await api(`/projects/${projectId}/clips`);
        const me = rows.find((r) => r.id === clip.id);
        if (me) setStatus(me);
      } catch (e) { setError(e instanceof Error ? e.message : "Lost contact with the server."); }
    }, 3000);
    return () => clearInterval(i);
  }, [status.render_status, projectId, clip.id]);

  useEffect(() => {
    if (status.render_status !== "done" || !status.output_path) return;
    createClient().storage.from("clips").createSignedUrl(status.output_path, 3600).then(({ data }) => setResultUrl(data?.signedUrl ?? null));
  }, [status.render_status, status.output_path]);

  function seek(x: number) { if (video.current) video.current.currentTime = x; setT(x); }
  function onTime() {
    const v = video.current;
    if (!v) return;
    if (v.currentTime >= end || v.currentTime < start - 0.3) v.currentTime = start;
    setT(v.currentTime);
    if (bg.current && Math.abs(bg.current.currentTime - v.currentTime) > 0.25) bg.current.currentTime = v.currentTime;
  }
  function toggle() {
    const v = video.current;
    if (!v) return;
    if (v.paused) { if (v.currentTime >= end || v.currentTime < start) v.currentTime = start; void v.play(); } else v.pause();
  }
  function changeStart(x: number) {
    const v = clamp(x, wMin, end - MIN_LEN);
    setStart(v); if (end - v > MAX_LEN) setEnd(v + MAX_LEN); seek(v);
  }
  function changeEnd(x: number) {
    const v = clamp(x, start + MIN_LEN, wMax);
    setEnd(v); if (v - start > MAX_LEN) setStart(v - MAX_LEN); seek(Math.max(start, v - 0.8));
  }

  async function exportClip() {
    setError(null); setExporting(true); setResultUrl(null);
    try {
      await api(`/projects/${projectId}/render`, "POST", {
        clip_ids: [clip.id], start_seconds: +start.toFixed(2), end_seconds: +end.toFixed(2), aspect, fit,
        captions: { enabled: on, style, font_size_pct: size, position, offset_pct: offset, highlight_keywords: highlight },
      });
      setStatus({ render_status: "queued", render_error: null, output_path: null });
    } catch (e) { setError(e instanceof Error ? e.message : "Could not start the export."); }
    finally { setExporting(false); }
  }
  async function download() {
    const name = `${(clip.title ?? "clip").replace(/[^\w -]/g, "")}.mp4`;
    const { data } = await createClient().storage.from("clips").createSignedUrl(status.output_path!, 3600, { download: name });
    if (data) location.assign(data.signedUrl); else setError("Could not start the download.");
  }

  const f = FRAME[aspect];
  const textStyle: React.CSSProperties = {
    fontSize: `${size}cqmin`, lineHeight: 1.15, fontFamily: style === "minimal" ? "system-ui, sans-serif" : "Anton, Impact, sans-serif",
    fontWeight: style === "minimal" ? 600 : 400, WebkitTextStroke: style === "minimal" ? undefined : "0.14em #000", paintOrder: "stroke fill",
    ...(style === "minimal" ? { background: "rgba(0,0,0,.6)", padding: "0.15em 0.4em", borderRadius: "0.2em" } : {}),
  };
  const pos: React.CSSProperties = position === "middle" ? { top: "50%", transform: "translateY(-50%)" } : position === "top" ? { top: `${offset}cqh` } : { bottom: `${offset}cqh` };

  return (
    <div className="mx-auto max-w-6xl">
      <Link href={`/dashboard/projects/${projectId}`} className="text-sm text-mist hover:text-white">Back to {projectTitle}</Link>
      <h1 className="mt-3 font-display text-3xl font-semibold">{clip.title ?? "Edit clip"}</h1>
      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,440px)_1fr]">
        <div>
          <div style={{ aspectRatio: f.ratio, maxWidth: f.max, containerType: "size" }} className="relative mx-auto w-full overflow-hidden rounded-xl bg-black">
            {fit === "blur" && <video ref={bg} src={videoUrl} muted playsInline aria-hidden className="absolute inset-0 h-full w-full scale-125 object-cover opacity-80 blur-2xl" />}
            <video ref={video} src={videoUrl} playsInline preload="auto" onTimeUpdate={onTime}
              onPlay={() => { setPlaying(true); void bg.current?.play(); }} onPause={() => { setPlaying(false); bg.current?.pause(); }}
              onSeeked={() => { if (bg.current && video.current) bg.current.currentTime = video.current.currentTime; }}
              className={`absolute inset-0 h-full w-full ${fit === "blur" ? "object-contain" : "object-cover"}`} />
            {chunk && (
              <div className="pointer-events-none absolute inset-x-0 flex justify-center px-[7cqw] text-center" style={pos} aria-hidden>
                <p key={style === "pop" ? chunk.start : "c"} className={style === "pop" ? "cf-pop" : ""} style={textStyle}>
                  {chunk.words.map((w, i) => (
                    <span key={i} style={{ color: style === "karaoke" && i === activeIdx ? "#8b5cf6" : i === kw || (style === "pop" && highlight && keywordIndex([w.word]) === 0) ? "#ffe500" : "#fff" }}>
                      {style === "minimal" ? w.word : w.word.toUpperCase()}{" "}
                    </span>
                  ))}
                </p>
              </div>
            )}
          </div>
          <p className="mx-auto mt-2 text-center text-xs text-mist">Preview approximates the export; the render uses FFmpeg.</p>
          <div className="mt-3 flex items-center justify-center gap-3">
            <button onClick={toggle} className={btn}>{playing ? "Pause" : "Play clip"}</button>
            <span className="text-sm text-mist" aria-live="off">{fmt(Math.max(0, t - start))} / {fmt(end - start)}</span>
          </div>
        </div>

        <div className="space-y-6">
          <section className="rounded-2xl border border-line bg-coal p-5" aria-labelledby="trim">
            <h2 id="trim" className="font-display text-lg font-medium">Trim</h2>
            <div className="relative mt-4 h-2 rounded-full bg-slate2" aria-hidden>
              <div className="absolute h-full rounded-full bg-violet-500" style={{ left: `${((start - wMin) / (wMax - wMin)) * 100}%`, width: `${((end - start) / (wMax - wMin)) * 100}%` }} />
            </div>
            {([["Start", start, changeStart, () => changeStart(t)], ["End", end, changeEnd, () => changeEnd(t)]] as const).map(([label, val, set, here]) => (
              <div key={label} className="mt-4 flex items-center gap-3">
                <label className="w-24 text-sm text-mist" htmlFor={`trim-${label}`}>{label} {fmt(val)}</label>
                <input id={`trim-${label}`} type="range" min={wMin} max={wMax} step={0.1} value={val} onChange={(e) => set(Number(e.target.value))} className="flex-1 accent-violet-500" />
                <button onClick={here} className={btn}>Use playhead</button>
              </div>
            ))}
            <p className="mt-3 text-xs text-mist">Length {fmt(end - start)}. You can extend up to a minute beyond the suggested range. Clips run {MIN_LEN} to {MAX_LEN} seconds.</p>
          </section>

          <section className="rounded-2xl border border-line bg-coal p-5" aria-labelledby="fmt">
            <h2 id="fmt" className="font-display text-lg font-medium">Format and captions</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className="text-sm text-mist">Aspect ratio<select className={`${field} mt-1 block w-full`} value={aspect} onChange={(e) => setAspect(e.target.value)}>
                <option value="9:16">Vertical 9:16</option><option value="1:1">Square 1:1</option><option value="16:9">Landscape 16:9</option></select></label>
              <label className="text-sm text-mist">Framing<select className={`${field} mt-1 block w-full`} value={fit} onChange={(e) => setFit(e.target.value)}>
                <option value="fill">Fill (center crop)</option><option value="blur">Fit over blurred background</option></select></label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={on} onChange={(e) => setOn(e.target.checked)} />Captions on</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={highlight} disabled={!on} onChange={(e) => setHighlight(e.target.checked)} />Highlight keywords</label>
              <label className="text-sm text-mist">Style<select disabled={!on} className={`${field} mt-1 block w-full disabled:opacity-40`} value={style} onChange={(e) => setStyle(e.target.value as CaptionStyle)}>
                {STYLES.map((s) => <option key={s} value={s}>{STYLE_LABELS[s]}</option>)}</select></label>
              <label className="text-sm text-mist">Position<select disabled={!on} className={`${field} mt-1 block w-full disabled:opacity-40`} value={position} onChange={(e) => setPosition(e.target.value)}>
                <option value="bottom">Bottom</option><option value="middle">Middle</option><option value="top">Top</option></select></label>
              <label className="text-sm text-mist">Font size {size}<input type="range" min={4} max={16} step={0.5} disabled={!on} value={size} onChange={(e) => setSize(Number(e.target.value))} className="mt-2 block w-full accent-violet-500" /></label>
              <label className="text-sm text-mist">Distance from edge {offset}%<input type="range" min={0} max={40} disabled={!on || position === "middle"} value={offset} onChange={(e) => setOffset(Number(e.target.value))} className="mt-2 block w-full accent-violet-500" /></label>
            </div>
          </section>

          <section className="rounded-2xl border border-line bg-coal p-5" aria-labelledby="exp" aria-live="polite">
            <h2 id="exp" className="font-display text-lg font-medium">Export</h2>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button onClick={exportClip} disabled={exporting || busy(status.render_status)} className="rounded-full bg-violet-600 px-6 py-2.5 text-sm font-medium transition hover:bg-violet-500 disabled:opacity-50">
                {busy(status.render_status) ? (status.render_status === "queued" ? "Queued…" : "Rendering…") : exporting ? "Starting…" : "Export MP4"}
              </button>
              {status.render_status === "done" && <button onClick={download} className={btn}>Download</button>}
            </div>
            {status.render_status === "failed" && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{status.render_error ?? "The export failed."}</p>}
            {error && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}
            {resultUrl && status.render_status === "done" && (
              <div className="mt-4"><p className="mb-2 text-sm text-emerald-300">Rendered file</p>
                <video src={resultUrl} controls className="max-h-[520px] rounded-lg bg-black" /></div>)}
          </section>
        </div>
      </div>
    </div>
  );
}
