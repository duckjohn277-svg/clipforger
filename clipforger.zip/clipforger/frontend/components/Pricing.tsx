import Link from "next/link";
import { plans } from "@/lib/content";

export default function Pricing() {
  return (
    <section id="pricing" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-24">
      <h2 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">Pricing that scales with your uploads.</h2>
      <div className="mt-14 grid gap-5 md:grid-cols-3">
        {plans.map((p) => (
          <div key={p.name} className={`flex flex-col rounded-2xl border p-7 ${p.featured ? "border-violet-500 bg-violet-600/10" : "border-line bg-coal"}`}>
            <h3 className="font-display text-xl font-medium">{p.name}</h3>
            <p className="mt-4"><span className="font-display text-5xl font-semibold">{p.price}</span> <span className="text-mist">{p.note}</span></p>
            <ul className="mt-6 flex-1 space-y-3 text-sm text-white/85">
              {p.items.map((it) => (<li key={it} className="flex gap-2"><span aria-hidden className="text-violet-400">✓</span>{it}</li>))}
            </ul>
            <Link href="/signup" className={`mt-8 rounded-full py-3 text-center text-sm font-medium transition ${p.featured ? "bg-violet-600 hover:bg-violet-500" : "border border-line hover:border-violet-400"}`}>{p.cta}</Link>
          </div>
        ))}
      </div>
      <p className="mt-6 text-sm text-mist">Placeholder pricing. Billing is not wired up yet.</p>
    </section>
  );
}
