"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";

export default function DeleteProject({ projectId, title }: { projectId: string; title: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function remove() {
    if (!window.confirm(`Delete "${title}"? Its video, transcript and rendered clips will be removed permanently.`)) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/projects/${projectId}`, "DELETE");
      router.push("/dashboard");
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete the project.");
      setBusy(false);
    }
  }

  return (
    <section aria-labelledby="delete-heading" className="mt-10 rounded-2xl border border-red-500/30 bg-coal p-5">
      <h2 id="delete-heading" className="font-display text-xl font-medium">Delete project</h2>
      <p className="mt-2 text-mist">Removes the video, transcript and all rendered clips. This cannot be undone.</p>
      {error && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}
      <button type="button" onClick={remove} disabled={busy}
        className="mt-4 rounded-full border border-red-500/50 px-6 py-2.5 text-sm font-medium text-red-300 transition hover:bg-red-500/10 disabled:opacity-50">
        {busy ? "Deleting…" : "Delete project"}
      </button>
    </section>
  );
}
