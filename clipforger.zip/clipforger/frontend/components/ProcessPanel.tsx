"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type State = { status: string; processing_step: string | null; error_message: string | null };
const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
const STEPS: Record<string, string> = {
  queued: "Waiting for a worker", downloading: "Fetching your video", probing: "Reading video details",
  extracting_audio: "Extracting audio", saving_audio: "Saving audio", transcribing: "Transcribing speech", finding_moments: "Finding the best moments", done: "Done",
};

async function api(path: string, method = "GET") {
  const { data: { session } } = await createClient().auth.getSession();
  if (!session) throw new Error("Your session expired. Log in again.");
  let res: Response;
  try { res = await fetch(`${API}${path}`, { method, headers: { Authorization: `Bearer ${session.access_token}` } }); }
  catch { throw new Error("Could not reach the processing server. Is the backend running?"); }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.detail ?? `Request failed (${res.status}).`);
  return body;
}

export default function ProcessPanel({ projectId, initial, clipCount }: { projectId: string; initial: State; clipCount: number }) {
  const router = useRouter();
  const [s, setS] = useState<State>(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const processing = s.status === "processing";

  const poll = useCallback(async () => {
    try {
      const p = await api(`/projects/${projectId}`);
      setS(p);
      if (p.status !== "processing") router.refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Lost contact with the server."); }
  }, [projectId, router]);

  useEffect(() => {
    if (!processing) return;
    const t = setInterval(poll, 3000);
    return () => clearInterval(t);
  }, [processing, poll]);

  async function start() {
    setError(null); setBusy(true);
    try { await api(`/projects/${projectId}/process`, "POST"); await poll(); }
    catch (e) { setError(e instanceof Error ? e.message : "Could not start processing."); }
    finally { setBusy(false); }
  }

  return (
    <section className="mt-6 rounded-2xl border border-line bg-coal p-5" aria-live="polite">
      <h2 className="font-display text-xl font-medium">Processing</h2>
      {(s.status === "uploaded" || s.status === "failed" || s.status === "audio_ready") && (
        <>
          {s.status === "failed" && s.error_message && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{s.error_message}</p>}
          <p className="mt-3 text-mist">Transcribe the video and find the moments most worth clipping. Long videos can take a while; you can leave this page.</p>
          <button onClick={start} disabled={busy} className="mt-4 rounded-full bg-violet-600 px-6 py-2.5 text-sm font-medium transition hover:bg-violet-500 disabled:opacity-50">
            {busy ? "Starting…" : s.status === "failed" ? "Try again" : "Start processing"}
          </button>
        </>
      )}
      {processing && (
        <p className="mt-3 flex items-center gap-3 text-mist">
          <span aria-hidden className="h-2.5 w-2.5 animate-pulse rounded-full bg-violet-500" />
          {STEPS[s.processing_step ?? "queued"] ?? "Working"}…
        </p>
      )}
      {s.status === "ready" && <p className="mt-3 text-emerald-300">{clipCount > 0 ? `Analysis complete: ${clipCount} clips suggested. Choose a format and caption style below, then render them.` : "Analysis complete, but no moment was strong enough to suggest."}</p>}
      {error && <p role="alert" className="mt-3 rounded-lg bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>}
    </section>
  );
}
