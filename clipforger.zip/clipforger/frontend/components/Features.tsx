import { features } from "@/lib/content";

export default function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-24">
      <h2 className="max-w-2xl font-display text-4xl font-semibold tracking-tight sm:text-5xl">Clips you would actually post.</h2>
      <div className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-3">
        {features.map((f) => (
          <article key={f.title} className="bg-coal p-7 transition hover:bg-slate2">
            <h3 className="font-display text-xl font-medium">{f.title}</h3>
            <p className="mt-3 text-mist">{f.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
