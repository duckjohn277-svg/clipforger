"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Logo } from "./Nav";

export default function AuthForm({ mode, initialError }: { mode: "login" | "signup"; initialError?: string }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState<"form" | "google" | null>(null);
  const [error, setError] = useState<string | null>(initialError ?? null);
  const [notice, setNotice] = useState<string | null>(null);
  const isLogin = mode === "login";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setNotice(null); setBusy("form");
    const supabase = createClient();
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.replace("/dashboard"); router.refresh();
      } else {
        const { data, error } = await supabase.auth.signUp({
          email, password, options: { emailRedirectTo: `${location.origin}/auth/callback` },
        });
        if (error) throw error;
        if (data.session) { router.replace("/dashboard"); router.refresh(); }
        else setNotice("Check your email and click the confirmation link to finish signing up.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again.");
    } finally { setBusy(null); }
  }

  async function google() {
    setError(null); setBusy("google");
    const { error } = await createClient().auth.signInWithOAuth({
      provider: "google", options: { redirectTo: `${location.origin}/auth/callback` },
    });
    if (error) { setError(error.message); setBusy(null); }
  }

  const field = "w-full rounded-xl border border-line bg-ink px-4 py-3 outline-none transition focus:border-violet-500";
  return (
    <main className="grid min-h-screen place-items-center px-5 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center"><Logo /></div>
        <div className="rounded-2xl border border-line bg-coal p-7">
          <h1 className="font-display text-2xl font-semibold">{isLogin ? "Log in to Clipforger" : "Create your account"}</h1>
          <button onClick={google} disabled={busy !== null} type="button"
            className="mt-6 w-full rounded-xl border border-line py-3 text-sm font-medium transition hover:border-violet-400 disabled:opacity-50">
            {busy === "google" ? "Redirecting to Google…" : "Continue with Google"}
          </button>
          <div className="my-5 flex items-center gap-3 text-xs text-mist"><span className="h-px flex-1 bg-line" />or<span className="h-px flex-1 bg-line" /></div>
          <form onSubmit={onSubmit} className="space-y-3">
            <label className="block text-sm">Email
              <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={`${field} mt-1`} />
            </label>
            <label className="block text-sm">Password
              <input type="password" required minLength={8} autoComplete={isLogin ? "current-password" : "new-password"}
                value={password} onChange={(e) => setPassword(e.target.value)} className={`${field} mt-1`} />
            </label>
            {error && <p role="alert" className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
            {notice && <p role="status" className="rounded-lg bg-violet-600/15 px-3 py-2 text-sm text-violet-400">{notice}</p>}
            <button type="submit" disabled={busy !== null} className="w-full rounded-xl bg-violet-600 py-3 font-medium transition hover:bg-violet-500 disabled:opacity-50">
              {busy === "form" ? (isLogin ? "Logging in…" : "Creating account…") : isLogin ? "Log in" : "Create account"}
            </button>
          </form>
          {!isLogin && <p className="mt-3 text-xs text-mist">Use at least 8 characters.</p>}
        </div>
        <p className="mt-6 text-center text-sm text-mist">
          {isLogin ? "New here? " : "Already have an account? "}
          <Link href={isLogin ? "/signup" : "/login"} className="text-violet-400 hover:underline">{isLogin ? "Create an account" : "Log in"}</Link>
        </p>
      </div>
    </main>
  );
}
