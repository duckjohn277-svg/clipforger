import { steps } from "@/lib/content";

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="scroll-mt-20 border-y border-line bg-coal px-5 py-24">
      <div className="mx-auto max-w-6xl">
        <h2 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">From one long video to a week of posts.</h2>
        <ol className="mt-14 grid gap-8 md:grid-cols-5">
          {steps.map((s, i) => (
            <li key={s.title} className="border-t border-violet-500 pt-5">
              <span className="text-sm text-violet-400">Step {i + 1}</span>
              <h3 className="mt-1 font-display text-xl font-medium">{s.title}</h3>
              <p className="mt-2 text-sm text-mist">{s.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
