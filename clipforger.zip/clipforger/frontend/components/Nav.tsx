import Link from "next/link";

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight">
      <span aria-hidden className="grid h-7 w-7 place-items-center rounded-lg bg-violet-600">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 2h4v10H2zM8 2h4v6H8z" fill="#fff" /></svg>
      </span>
      Clipforger AI
    </Link>
  );
}

export default function Nav() {
  const links = [["Features", "#features"], ["How it works", "#how-it-works"], ["Pricing", "#pricing"], ["FAQ", "#faq"]];
  return (
    <header className="sticky top-0 z-40 border-b border-line/60 bg-ink/80 backdrop-blur">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5" aria-label="Main">
        <Logo />
        <ul className="hidden gap-8 text-sm text-mist md:flex">
          {links.map(([l, h]) => (<li key={h}><a href={h} className="transition hover:text-white">{l}</a></li>))}
        </ul>
        <div className="flex items-center gap-2">
          <Link href="/login" className="hidden px-3 py-2 text-sm text-mist transition hover:text-white sm:block">Log in</Link>
          <Link href="/signup" className="rounded-full bg-white px-4 py-2 text-sm font-medium text-ink transition hover:bg-violet-400">Get started</Link>
        </div>
      </nav>
    </header>
  );
}
