import { faqs } from "@/lib/content";

export default function Faq() {
  return (
    <section id="faq" className="mx-auto max-w-3xl scroll-mt-20 px-5 pb-28">
      <h2 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">Questions</h2>
      <div className="mt-10 divide-y divide-line border-y border-line">
        {faqs.map((f) => (
          <details key={f.q} className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium">
              {f.q}
              <span aria-hidden className="text-violet-400 transition group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 text-mist">{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
