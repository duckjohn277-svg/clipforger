alter table public.projects
  add column processing_step text,
  add column error_message text,
  add column audio_path text;

alter table public.projects drop constraint projects_status_check;
alter table public.projects add constraint projects_status_check
  check (status in ('uploaded','processing','audio_ready','ready','failed'));

-- Private bucket for extracted audio. No user policies: only the backend (service role) reads and writes it.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('audio', 'audio', false, 104857600, array['audio/mpeg'])
on conflict (id) do nothing;
