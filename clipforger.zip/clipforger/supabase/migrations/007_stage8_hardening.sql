-- Stage 8: job leases, a durable storage cleanup queue, and deletion triggers.

-- Leases: a running job keeps extending locked_until (heartbeat). If the worker dies,
-- the lease expires and the job is recovered as failed, so it can be retried.
alter table public.projects add column if not exists locked_until timestamptz;
alter table public.clips add column if not exists locked_until timestamptz;
create index if not exists projects_lease_idx on public.projects (locked_until) where status = 'processing';
create index if not exists clips_lease_idx on public.clips (locked_until) where render_status in ('queued','rendering');

-- Files that must be deleted from Storage. Rows are written by triggers below, so any
-- deletion path (API, client, cascade from deleting an auth user) leaves a record.
create table if not exists public.storage_cleanup (
  id bigint generated always as identity primary key,
  bucket text not null check (bucket in ('videos','audio','clips')),
  path text not null,
  project_id uuid not null,
  user_id uuid not null,
  attempts integer not null default 0,
  last_error text,
  created_at timestamptz not null default now(),
  unique (bucket, path)
);
create index if not exists storage_cleanup_project_idx on public.storage_cleanup (project_id);
alter table public.storage_cleanup enable row level security;
-- No policies on purpose: only the service role (backend) and the triggers use this table.

create or replace function public.enqueue_project_storage() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.storage_cleanup (bucket, path, project_id, user_id)
    values ('audio', old.user_id::text || '/' || old.id::text || '.mp3', old.id, old.user_id)
    on conflict (bucket, path) do nothing;
  if old.storage_path is not null then
    insert into public.storage_cleanup (bucket, path, project_id, user_id)
      values ('videos', old.storage_path, old.id, old.user_id)
      on conflict (bucket, path) do nothing;
  end if;
  if old.audio_path is not null then
    insert into public.storage_cleanup (bucket, path, project_id, user_id)
      values ('audio', old.audio_path, old.id, old.user_id)
      on conflict (bucket, path) do nothing;
  end if;
  return old;
end $$;

create trigger projects_enqueue_storage after delete on public.projects
  for each row execute function public.enqueue_project_storage();

create or replace function public.enqueue_clip_storage() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.storage_cleanup (bucket, path, project_id, user_id)
    values ('clips', old.user_id::text || '/' || old.project_id::text || '/' || old.id::text || '.mp4',
            old.project_id, old.user_id)
    on conflict (bucket, path) do nothing;
  if old.output_path is not null then
    insert into public.storage_cleanup (bucket, path, project_id, user_id)
      values ('clips', old.output_path, old.project_id, old.user_id)
      on conflict (bucket, path) do nothing;
  end if;
  return old;
end $$;

create trigger clips_enqueue_storage after delete on public.clips
  for each row execute function public.enqueue_clip_storage();
