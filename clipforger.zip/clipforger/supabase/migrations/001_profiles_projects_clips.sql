create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'free',
  created_at timestamptz not null default now()
);
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  status text not null default 'uploaded' check (status in ('uploaded','processing','ready','failed')),
  duration_seconds numeric,
  size_bytes bigint,
  created_at timestamptz not null default now()
);
create table public.clips (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  start_seconds numeric not null,
  end_seconds numeric not null,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.clips enable row level security;
create policy "own profile" on public.profiles for select using (auth.uid() = id);
create policy "own projects" on public.projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own clips" on public.clips for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
