alter table public.clips add constraint clips_range_check check (end_seconds > start_seconds);
