alter table public.clips
  add column render_status text not null default 'none'
    check (render_status in ('none','queued','rendering','done','failed')),
  add column render_error text,
  add column output_path text,
  add column render_options jsonb;

-- Rendered clips. The backend writes with the service role; users may only read their own folder.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('clips', 'clips', false, 524288000, array['video/mp4'])
on conflict (id) do nothing;
create policy "users read own rendered clips" on storage.objects for select
  using (bucket_id = 'clips' and (storage.foldername(name))[1] = auth.uid()::text);
