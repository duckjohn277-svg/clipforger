create table public.transcripts (
  project_id uuid primary key references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  language text,
  segments jsonb not null,
  words jsonb not null,
  created_at timestamptz not null default now()
);
alter table public.transcripts enable row level security;
create policy "own transcripts" on public.transcripts for select using (auth.uid() = user_id);

alter table public.clips
  add column title text,
  add column category text,
  add column score integer,
  add column reason text;
